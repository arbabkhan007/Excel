"""Write every source file of a generator into one markdown document.

    python tools/export_source_md.py                   # -> SOURCE_CODE.md
    python tools/export_source_md.py --product social  # -> SOURCE_CODE_SOCIAL.md
    python tools/export_source_md.py -o /tmp/src.md

Handy when the code has to travel somewhere that is not a git checkout:
one file, every module in reading order, each in a fenced block with its
real path above it, plus a short description taken from the module's own
docstring so the two can never disagree.
"""

from __future__ import annotations

import argparse
import ast
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

SHARED_TOOLS = [
    "tools/export_source_md.py",
    "tools/make_download_zip.py",
]

# ---------------------------------------------------------------------------
# Product A - pet sitting
# ---------------------------------------------------------------------------

PET_SECTIONS = [
    ("1. Run it",
     "Save the files below keeping these exact paths, then run the one "
     "liner. Nothing else is needed - no project file, no build step.\n\n"
     "```bash\n"
     "pip install XlsxWriter\n"
     "python build_pet_sitting_workbook.py\n"
     "```\n\n"
     "The workbook lands in `output/Pet Sitting Business Spreadsheet.xlsx`.",
     ["build_pet_sitting_workbook.py"]),
    ("2. The package",
     "Configuration, the formula template engine, cell formats, the sheet "
     "writer and the demo data. These are the parts every tab leans on.",
     ["pet_sitting_spreadsheet/__init__.py",
      "pet_sitting_spreadsheet/__main__.py",
      "pet_sitting_spreadsheet/cli.py",
      "pet_sitting_spreadsheet/config.py",
      "pet_sitting_spreadsheet/layout.py",
      "pet_sitting_spreadsheet/formats.py",
      "pet_sitting_spreadsheet/writer.py",
      "pet_sitting_spreadsheet/names.py",
      "pet_sitting_spreadsheet/build.py",
      "pet_sitting_spreadsheet/sample_data.py"]),
    ("3. The registers",
     "One module per data tab. Each returns a `SheetSpec` - a list of "
     "columns with their formulas - and the writer turns that into a "
     "formatted, validated, protected sheet.",
     ["pet_sitting_spreadsheet/sheets/__init__.py",
      "pet_sitting_spreadsheet/sheets/common.py",
      "pet_sitting_spreadsheet/sheets/lists.py",
      "pet_sitting_spreadsheet/sheets/settings.py",
      "pet_sitting_spreadsheet/sheets/services.py",
      "pet_sitting_spreadsheet/sheets/clients.py",
      "pet_sitting_spreadsheet/sheets/pets.py",
      "pet_sitting_spreadsheet/sheets/bookings.py",
      "pet_sitting_spreadsheet/sheets/visits.py",
      "pet_sitting_spreadsheet/sheets/health.py",
      "pet_sitting_spreadsheet/sheets/incidents.py",
      "pet_sitting_spreadsheet/sheets/messages.py",
      "pet_sitting_spreadsheet/sheets/invoices.py",
      "pet_sitting_spreadsheet/sheets/payments.py",
      "pet_sitting_spreadsheet/sheets/expenses.py",
      "pet_sitting_spreadsheet/sheets/mileage.py",
      "pet_sitting_spreadsheet/sheets/staff.py",
      "pet_sitting_spreadsheet/sheets/inventory.py",
      "pet_sitting_spreadsheet/sheets/reminders.py"]),
    ("4. The pages",
     "The tabs that read the registers: the hidden calculation engine, the "
     "dashboard, the reports, the planner, the welcome tab, the printable "
     "pages and the help tab.",
     ["pet_sitting_spreadsheet/sheets/calc.py",
      "pet_sitting_spreadsheet/sheets/dashboard.py",
      "pet_sitting_spreadsheet/sheets/reports.py",
      "pet_sitting_spreadsheet/sheets/budget.py",
      "pet_sitting_spreadsheet/sheets/start_here.py",
      "pet_sitting_spreadsheet/sheets/printables.py",
      "pet_sitting_spreadsheet/sheets/help_tab.py"]),
    ("5. Quality checks (optional)",
     "Not needed to build the workbook - these are the checks that keep it "
     "honest. The first two need `openpyxl`, the third needs `formulas`.",
     ["tools/validate_workbook.py",
      "tools/check_sample_data.py",
      "tools/recalc_check.py"] + SHARED_TOOLS),
]

PET = {
    "package": "pet_sitting_spreadsheet",
    "builder": "build_pet_sitting_workbook.py",
    "doc": "README.md",
    "tabs": 27,
    "title": "Pet Sitting & Dog Walking Business Spreadsheet",
    "subtitle": ("Complete source code of the generator that writes the "
                 "`.xlsx` product."),
    "output": "SOURCE_CODE.md",
    "intro": [
        "Writes a 27 tab `.xlsx` workbook with about 50,000 formulas: client "
        "and pet records, bookings, visit logs, pricing, invoices, payments, "
        "expenses, mileage, a dashboard, reports and automatic reminders. "
        "Document author is **Novality Store**; every formula cell is locked "
        "and every sheet protected with the password **`premium`**, while "
        "the cells you are meant to type in stay open.",
        "",
        "Pure Python, one dependency. Tested on XlsxWriter 3.2.0 and on the "
        "much older 0.3.0, so it does not rely on anything recent. The "
        "workbook itself is Excel 2010 safe — no dynamic arrays, no "
        "`XLOOKUP`, no `IFS`, nothing that needs array entry — and it opens "
        "in Google Sheets, LibreOffice and Numbers.",
        "",
        "```bash",
        "python build_pet_sitting_workbook.py --help",
        "",
        "  -o, --output PATH     where to write the file",
        "  --blank               no example data, just the empty workbook",
        "  --no-protect          leave the sheets unlocked",
        "  --password TEXT       protection password (default: premium)",
        "  --author TEXT         document author  (default: Novality Store)",
        "  --business TEXT       business name on the cover and invoices",
        "  --currency SYMBOL     currency symbol  (default: $)",
        "  --unit {km,miles}     mileage unit",
        "  --rows N              rows of capacity in the big registers",
        "  --today YYYY-MM-DD    pretend it is this date (for the demo data)",
        "```",
    ],
    "sections": PET_SECTIONS,
}

# ---------------------------------------------------------------------------
# Product B - social media content planner
# ---------------------------------------------------------------------------

_PKG = "social_media_spreadsheet"

SOCIAL_SECTIONS = [
    ("1. Run it",
     "Save the files below keeping these exact paths, then run the one "
     "liner. Nothing else is needed - no project file, no build step.\n\n"
     "```bash\n"
     "pip install XlsxWriter\n"
     "python build_social_media_workbook.py\n"
     "```\n\n"
     "The workbook lands in "
     "`output/Social Media Content Planner.xlsx`.",
     ["build_social_media_workbook.py"]),
    ("2. The package",
     "Configuration, the formula template engine, cell formats, the sheet "
     "writer, the cross sheet names and the demo data. These are the parts "
     "every tab leans on.",
     [f"{_PKG}/__init__.py",
      f"{_PKG}/__main__.py",
      f"{_PKG}/cli.py",
      f"{_PKG}/config.py",
      f"{_PKG}/layout.py",
      f"{_PKG}/formats.py",
      f"{_PKG}/writer.py",
      f"{_PKG}/names.py",
      f"{_PKG}/build.py",
      f"{_PKG}/sample_data.py"]),
    ("3. Setup & planning registers",
     "One module per data tab. Each returns a `SheetSpec` - a list of "
     "columns with their formulas - and the writer turns that into a "
     "formatted, validated, protected sheet. These are the tabs you fill "
     "in before you start posting.",
     [f"{_PKG}/sheets/__init__.py",
      f"{_PKG}/sheets/common.py",
      f"{_PKG}/sheets/lists.py",
      f"{_PKG}/sheets/settings.py",
      f"{_PKG}/sheets/accounts.py",
      f"{_PKG}/sheets/personas.py",
      f"{_PKG}/sheets/pillars.py",
      f"{_PKG}/sheets/calendar_sheet.py",
      f"{_PKG}/sheets/ideas.py",
      f"{_PKG}/sheets/captions.py",
      f"{_PKG}/sheets/hashtags.py",
      f"{_PKG}/sheets/platforms.py"]),
    ("4. Campaign & production registers",
     "The tabs that run the work: campaigns and launches, the seasonal "
     "plan, collaborations, repurposing, research and the team.",
     [f"{_PKG}/sheets/campaigns.py",
      f"{_PKG}/sheets/launches.py",
      f"{_PKG}/sheets/seasonal.py",
      f"{_PKG}/sheets/influencers.py",
      f"{_PKG}/sheets/ugc.py",
      f"{_PKG}/sheets/repurposing.py",
      f"{_PKG}/sheets/competitors.py",
      f"{_PKG}/sheets/trends.py",
      f"{_PKG}/sheets/assets.py",
      f"{_PKG}/sheets/team.py",
      f"{_PKG}/sheets/tasks.py",
      f"{_PKG}/sheets/compliance.py"]),
    ("5. Measurement registers",
     "Where the numbers go in: monthly account analytics, per post "
     "performance, tests, paid promotion, goals and the budget.",
     [f"{_PKG}/sheets/analytics.py",
      f"{_PKG}/sheets/performance.py",
      f"{_PKG}/sheets/ab_tests.py",
      f"{_PKG}/sheets/ads.py",
      f"{_PKG}/sheets/goals.py",
      f"{_PKG}/sheets/budget.py"]),
    ("6. The pages",
     "The tabs that read the registers: the hidden calculation engine, the "
     "two dashboards, the calendar grid, the production pipeline, the "
     "brand voice page, the reports, the welcome tab, the printables and "
     "the help tab.",
     [f"{_PKG}/sheets/calc.py",
      f"{_PKG}/sheets/dashboard.py",
      f"{_PKG}/sheets/annual.py",
      f"{_PKG}/sheets/month_view.py",
      f"{_PKG}/sheets/workflow.py",
      f"{_PKG}/sheets/brand_voice.py",
      f"{_PKG}/sheets/reports.py",
      f"{_PKG}/sheets/start_here.py",
      f"{_PKG}/sheets/printables.py",
      f"{_PKG}/sheets/help_tab.py"]),
    ("7. Quality checks (optional)",
     "Not needed to build the workbook - these are the checks that keep it "
     "honest. The first two need `openpyxl`, the third needs `formulas`.",
     ["tools/validate_social_workbook.py",
      "tools/check_social_sample.py",
      "tools/recalc_check.py"] + SHARED_TOOLS),
]

SOCIAL = {
    "package": "social_media_spreadsheet",
    "builder": "build_social_media_workbook.py",
    "doc": "README_SOCIAL.md",
    "tabs": 43,
    "title": "Social Media Content Calendar & Analytics Planner",
    "subtitle": ("Complete source code of the generator that writes the "
                 "`.xlsx` product."),
    "output": "SOURCE_CODE_SOCIAL.md",
    "intro": [
        "Writes a 43 tab `.xlsx` workbook with over 110,000 formulas: a "
        "12 month content calendar, an idea bank, caption and hashtag "
        "banks, five platform planners, campaigns, launches, influencer "
        "and UGC tracking, repurposing, competitor and trend research, "
        "monthly analytics, per post performance, two dashboards, printable "
        "briefs and a reports page. Document author is **Novality Store**; "
        "every formula cell is locked and every sheet protected with the "
        "password **`premium`**, while the cells you are meant to type in "
        "stay open.",
        "",
        "Pure Python, one dependency. Tested on XlsxWriter 3.2.0 and on the "
        "much older 0.3.0, so it does not rely on anything recent. The "
        "workbook itself is Excel 2010 safe — no dynamic arrays, no "
        "`XLOOKUP`, no `IFS`, nothing that needs array entry — and it opens "
        "in Google Sheets, LibreOffice and Numbers.",
        "",
        "```bash",
        "python build_social_media_workbook.py --help",
        "",
        "  -o, --output PATH     where to write the file",
        "  --blank               no example data, just the empty workbook",
        "  --no-protect          leave the sheets unlocked",
        "  --password TEXT       protection password (default: premium)",
        "  --author TEXT         document author  (default: Novality Store)",
        "  --brand TEXT          brand name on the cover and the dashboards",
        "  --currency SYMBOL     currency symbol  (default: $)",
        "  --year YYYY           the year the calendar is built for",
        "  --rows N              rows of capacity in the big registers",
        "  --today YYYY-MM-DD    pretend it is this date (for the demo data)",
        "```",
    ],
    "sections": SOCIAL_SECTIONS,
}

# ---------------------------------------------------------------------------
# Product C - automated meal planner
# ---------------------------------------------------------------------------

_MEAL = "meal_planner_spreadsheet"

MEAL_SECTIONS = [
    ("1. Run it",
     "Save the files below keeping these exact paths, then run the one "
     "liner. Nothing else is needed - no project file, no build step.\n\n"
     "```bash\n"
     "pip install XlsxWriter\n"
     "python build_meal_planner_workbook.py\n"
     "```\n\n"
     "The workbook lands in "
     "`output/Meal Planner & Grocery List.xlsx`.",
     ["build_meal_planner_workbook.py"]),
    ("2. The package",
     "Configuration, the formula template engine, cell formats, the sheet "
     "writer, the cross sheet names and the demo household. These are the "
     "parts every tab leans on.",
     [f"{_MEAL}/__init__.py",
      f"{_MEAL}/__main__.py",
      f"{_MEAL}/cli.py",
      f"{_MEAL}/config.py",
      f"{_MEAL}/layout.py",
      f"{_MEAL}/formats.py",
      f"{_MEAL}/writer.py",
      f"{_MEAL}/names.py",
      f"{_MEAL}/build.py",
      f"{_MEAL}/sample_data.py"]),
    ("3. The food registers",
     "One module per data tab. Each returns a `SheetSpec` - a list of "
     "columns with their formulas - and the writer turns that into a "
     "formatted, validated, protected sheet. These five are the chain "
     "that makes the shopping list write itself.",
     [f"{_MEAL}/sheets/__init__.py",
      f"{_MEAL}/sheets/common.py",
      f"{_MEAL}/sheets/lists.py",
      f"{_MEAL}/sheets/settings.py",
      f"{_MEAL}/sheets/members.py",
      f"{_MEAL}/sheets/recipes.py",
      f"{_MEAL}/sheets/recipe_lines.py",
      f"{_MEAL}/sheets/ingredients.py",
      f"{_MEAL}/sheets/meal_plan.py",
      f"{_MEAL}/sheets/grocery.py"]),
    ("4. The kitchen registers",
     "What is in the house and what happens to it: the pantry, the "
     "staples, leftovers, waste, batch cooking, the shops and what you "
     "spend in them, events and goals.",
     [f"{_MEAL}/sheets/pantry.py",
      f"{_MEAL}/sheets/staples.py",
      f"{_MEAL}/sheets/leftovers.py",
      f"{_MEAL}/sheets/waste.py",
      f"{_MEAL}/sheets/prep.py",
      f"{_MEAL}/sheets/spending.py",
      f"{_MEAL}/sheets/store_prices.py",
      f"{_MEAL}/sheets/stores.py",
      f"{_MEAL}/sheets/events.py",
      f"{_MEAL}/sheets/goals.py"]),
    ("5. The pages",
     "The tabs that read the registers: the welcome page, the dashboard, "
     "the two planners, the filters, the money and nutrition pages, the "
     "converter and scaler, rotation, food safety, cold storage, "
     "sustainability, the reports, the three printables and the help "
     "tab.",
     [f"{_MEAL}/sheets/start_here.py",
      f"{_MEAL}/sheets/dashboard.py",
      f"{_MEAL}/sheets/weekly.py",
      f"{_MEAL}/sheets/monthly.py",
      f"{_MEAL}/sheets/filters.py",
      f"{_MEAL}/sheets/nutrition.py",
      f"{_MEAL}/sheets/budget.py",
      f"{_MEAL}/sheets/recipe_costs.py",
      f"{_MEAL}/sheets/converter.py",
      f"{_MEAL}/sheets/rotation.py",
      f"{_MEAL}/sheets/allergens.py",
      f"{_MEAL}/sheets/fridge.py",
      f"{_MEAL}/sheets/sustainability.py",
      f"{_MEAL}/sheets/reports.py",
      f"{_MEAL}/sheets/printables.py",
      f"{_MEAL}/sheets/help_tab.py"]),
    ("6. Quality checks (optional)",
     "Not needed to build the workbook - these are the checks that keep "
     "it honest. The first two need `openpyxl`, the third needs "
     "`formulas`.",
     ["tools/validate_meal_workbook.py",
      "tools/check_meal_sample.py",
      "tools/recalc_check.py"] + SHARED_TOOLS),
]

MEAL = {
    "package": "meal_planner_spreadsheet",
    "builder": "build_meal_planner_workbook.py",
    "doc": "README_MEAL.md",
    "tabs": 36,
    "title": "Automated Meal Planner & Grocery List Spreadsheet",
    "subtitle": ("Complete source code of the generator that writes the "
                 "`.xlsx` product."),
    "output": "SOURCE_CODE_MEAL.md",
    "closing": ("**Activate the first tab** and close the file - there "
                "is no hidden sheet to hide in this one."),
    "engine_heading": "Ranking columns instead of a hidden engine",
    "intro": [
        "Writes a 36 tab `.xlsx` workbook with over 72,000 formulas: a "
        "weekly and a monthly meal planner, a recipe book with costed "
        "ingredient lines, a grocery list that builds itself from the "
        "plan and deducts the pantry, fridge and freezer tracking, "
        "leftovers and waste, a food budget, recipe costing and store "
        "price comparison, unit conversion and recipe scaling, dietary "
        "filters, calories and macros, batch cooking, meal rotation, "
        "food safety, a dashboard, reports and three printable pages. "
        "Document author is **Novality Store**; every formula cell is "
        "locked and every sheet protected with the password "
        "**`premium`**, while the cells you are meant to type in stay "
        "open.",
        "",
        "Pure Python, one dependency. Tested on XlsxWriter 3.2.0 and on "
        "the much older 0.3.0, so it does not rely on anything recent. "
        "The workbook itself is Excel 2010 safe \u2014 no dynamic arrays, "
        "no `XLOOKUP`, no `IFS`, nothing that needs array entry \u2014 and "
        "it opens in Google Sheets, LibreOffice and Numbers.",
        "",
        "```bash",
        "python build_meal_planner_workbook.py --help",
        "",
        "  -o, --output PATH     where to write the file",
        "  --blank               no example data, just the empty workbook",
        "  --no-protect          leave the sheets unlocked",
        "  --password TEXT       protection password (default: premium)",
        "  --author TEXT         document author  (default: Novality Store)",
        "  --household TEXT      household name on the cover and printables",
        "  --cook TEXT           the main cook / planner",
        "  --currency SYMBOL     currency symbol  (default: $)",
        "  --year YYYY           the year the planner is built for",
        "  --week-start DAY      Monday or Sunday",
        "  --servings N          default number of people a meal feeds",
        "  --budget AMOUNT       weekly food budget",
        "  --units {Metric,Imperial}   which unit set the drop downs lead with",
        "  --rows N              rows of capacity in the big registers",
        "  --today YYYY-MM-DD    pretend it is this date (for the demo data)",
        "```",
    ],
    "sections": MEAL_SECTIONS,
}

# ---------------------------------------------------------------------------
# Product D - cleaning business CRM
# ---------------------------------------------------------------------------

_CLEAN = "cleaning_business_spreadsheet"

CLEANING_SECTIONS = [
    ("1. Run it",
     "Save the files below keeping these exact paths, then run the one "
     "liner. Nothing else is needed - no project file, no build step.\n\n"
     "```bash\n"
     "pip install XlsxWriter\n"
     "python build_cleaning_workbook.py\n"
     "```\n\n"
     "The workbook lands in "
     "`output/Cleaning Business CRM & Pricing Calculator.xlsx`.",
     ["build_cleaning_workbook.py"]),
    ("2. The package",
     "Configuration, the formula template engine, cell formats, the sheet "
     "writer, the cross sheet names and the demo cleaning company. These "
     "are the parts every tab leans on.",
     [f"{_CLEAN}/__init__.py",
      f"{_CLEAN}/__main__.py",
      f"{_CLEAN}/cli.py",
      f"{_CLEAN}/config.py",
      f"{_CLEAN}/layout.py",
      f"{_CLEAN}/formats.py",
      f"{_CLEAN}/writer.py",
      f"{_CLEAN}/names.py",
      f"{_CLEAN}/build.py",
      f"{_CLEAN}/sample_data.py"]),
    ("3. The work registers",
     "One module per data tab. Each returns a `SheetSpec` - a list of "
     "columns with their formulas - and the writer turns that into a "
     "formatted, validated, protected sheet. These are the chain that "
     "turns an enquiry into a priced job and a paid invoice.",
     [f"{_CLEAN}/sheets/__init__.py",
      f"{_CLEAN}/sheets/common.py",
      f"{_CLEAN}/sheets/lists.py",
      f"{_CLEAN}/sheets/settings.py",
      f"{_CLEAN}/sheets/clients.py",
      f"{_CLEAN}/sheets/properties.py",
      f"{_CLEAN}/sheets/leads.py",
      f"{_CLEAN}/sheets/services.py",
      f"{_CLEAN}/sheets/quotes.py",
      f"{_CLEAN}/sheets/quote_lines.py",
      f"{_CLEAN}/sheets/jobs.py",
      f"{_CLEAN}/sheets/job_tasks.py",
      f"{_CLEAN}/sheets/checklists.py"]),
    ("4. The people and money registers",
     "Who did the work, what it cost and what came back in: staff, "
     "timesheets, job costing, invoices and their lines, payments, "
     "supplies, equipment, expenses, mileage, complaints, incidents and "
     "compliance documents.",
     [f"{_CLEAN}/sheets/employees.py",
      f"{_CLEAN}/sheets/timesheets.py",
      f"{_CLEAN}/sheets/job_costing.py",
      f"{_CLEAN}/sheets/invoices.py",
      f"{_CLEAN}/sheets/invoice_lines.py",
      f"{_CLEAN}/sheets/payments.py",
      f"{_CLEAN}/sheets/supplies.py",
      f"{_CLEAN}/sheets/supply_usage.py",
      f"{_CLEAN}/sheets/equipment.py",
      f"{_CLEAN}/sheets/expenses.py",
      f"{_CLEAN}/sheets/mileage.py",
      f"{_CLEAN}/sheets/complaints.py",
      f"{_CLEAN}/sheets/incidents.py",
      f"{_CLEAN}/sheets/safety.py"]),
    ("5. The pages",
     "The tabs that read the registers: the welcome page, the dashboard, "
     "the quote calculator, the month calendar, the staff rota, "
     "retention, the reports, the financial plan, the three printables "
     "and the help tab.",
     [f"{_CLEAN}/sheets/start_here.py",
      f"{_CLEAN}/sheets/dashboard.py",
      f"{_CLEAN}/sheets/quote_calc.py",
      f"{_CLEAN}/sheets/calendar_page.py",
      f"{_CLEAN}/sheets/staff_schedule.py",
      f"{_CLEAN}/sheets/retention.py",
      f"{_CLEAN}/sheets/reports.py",
      f"{_CLEAN}/sheets/financial.py",
      f"{_CLEAN}/sheets/printables.py",
      f"{_CLEAN}/sheets/help_tab.py"]),
    ("6. Quality checks (optional)",
     "Not needed to build the workbook - these are the checks that keep "
     "it honest. The first two need `openpyxl`, the third needs "
     "`formulas`.",
     ["tools/validate_cleaning_workbook.py",
      "tools/check_cleaning_sample.py",
      "tools/recalc_check.py"] + SHARED_TOOLS),
]

CLEANING = {
    "package": "cleaning_business_spreadsheet",
    "builder": "build_cleaning_workbook.py",
    "doc": "README_CLEANING.md",
    "tabs": 37,
    "title": "Cleaning Business CRM & Pricing Calculator",
    "subtitle": ("Complete source code of the generator that writes the "
                 "`.xlsx` product."),
    "output": "SOURCE_CODE_CLEANING.md",
    "closing": ("**Activate the first tab** and close the file - there "
                "is no hidden sheet to hide in this one."),
    "engine_heading": "Ranking columns instead of a hidden engine",
    "intro": [
        "Writes a 37 tab `.xlsx` workbook with over 110,000 formulas: a "
        "client CRM and property database, a lead pipeline, a priced "
        "service catalogue, a quote calculator that sizes a job from the "
        "property and prices it, quotes and estimates, a job scheduler "
        "with recurring visits, a month calendar, property specific "
        "cleaning checklists, staff records, a rota with attendance and "
        "timesheets, job costing and profit per job, invoices, payments, "
        "supplies, equipment, expenses, mileage, retention, complaints, "
        "safety documents, a dashboard, reports, a financial plan and "
        "three printable forms. Document author is **Novality Store**; "
        "every formula cell is locked and every sheet protected with the "
        "password **`premium`**, while the cells you are meant to type "
        "in stay open.",
        "",
        "Pure Python, one dependency. Tested on XlsxWriter 3.2.0 and on "
        "the much older 0.3.0, so it does not rely on anything recent. "
        "The workbook itself is Excel 2010 safe \u2014 no dynamic arrays, "
        "no `XLOOKUP`, no `IFS`, nothing that needs array entry \u2014 and "
        "it opens in Google Sheets, LibreOffice and Numbers.",
        "",
        "```bash",
        "python build_cleaning_workbook.py --help",
        "",
        "  -o, --output PATH     where to write the file",
        "  --blank               no example data, just the empty workbook",
        "  --no-protect          leave the sheets unlocked",
        "  --password TEXT       protection password (default: premium)",
        "  --author TEXT         document author  (default: Novality Store)",
        "  --business TEXT       business name on the cover and printables",
        "  --owner TEXT          owner / manager name",
        "  --currency SYMBOL     currency symbol  (default: $)",
        "  --currency-code CODE  three letter code (default: USD)",
        "  --year YYYY           the year the planner and reports open on",
        "  --week-start DAY      Monday or Sunday",
        "  --rate AMOUNT         hourly rate charged to the client",
        "  --pay AMOUNT          hourly pay rate of a cleaner",
        "  --minimum AMOUNT      minimum charge for any job",
        "  --tax PERCENT         sales tax / VAT rate, e.g. 20 for 20%",
        "  --terms DAYS          payment terms in days",
        "  --units {sq ft,sq m}  the area unit used for pricing",
        "  --distance {miles,km} the distance unit used for mileage",
        "  --rows N              rows of capacity in the big registers",
        "  --today YYYY-MM-DD    pretend it is this date (for the demo data)",
        "```",
    ],
    "sections": CLEANING_SECTIONS,
}

# ---------------------------------------------------------------------------
# Product E - handmade product pricing calculator
# ---------------------------------------------------------------------------

_MAKE = "handmade_pricing_spreadsheet"

HANDMADE_SECTIONS = [
    ("1. Run it",
     "Save the files below keeping these exact paths, then run the one "
     "liner. Nothing else is needed - no project file, no build step.\n\n"
     "```bash\n"
     "pip install XlsxWriter\n"
     "python build_handmade_workbook.py\n"
     "```\n\n"
     "The workbook lands in "
     "`output/Handmade Product Pricing & Profit Calculator.xlsx`.",
     ["build_handmade_workbook.py"]),
    ("2. The package",
     "Configuration, the formula template engine, cell formats, the sheet "
     "writer, the cross sheet names and the demo shop. These are the "
     "parts every tab leans on.",
     [f"{_MAKE}/__init__.py",
      f"{_MAKE}/__main__.py",
      f"{_MAKE}/cli.py",
      f"{_MAKE}/config.py",
      f"{_MAKE}/layout.py",
      f"{_MAKE}/formats.py",
      f"{_MAKE}/writer.py",
      f"{_MAKE}/names.py",
      f"{_MAKE}/build.py",
      f"{_MAKE}/sample_data.py"]),
    ("3. The costing registers",
     "One module per data tab. Each returns a `SheetSpec` - a list of "
     "columns with their formulas - and the writer turns that into a "
     "formatted, validated, protected sheet. These are the chain that "
     "turns a pile of materials and a number of minutes into a price: "
     "the catalog, the materials and the bill of materials, labour, "
     "packaging, postage, overhead and the marketplace fee table.",
     [f"{_MAKE}/sheets/__init__.py",
      f"{_MAKE}/sheets/common.py",
      f"{_MAKE}/sheets/lists.py",
      f"{_MAKE}/sheets/products.py",
      f"{_MAKE}/sheets/materials.py",
      f"{_MAKE}/sheets/material_usage.py",
      f"{_MAKE}/sheets/labor.py",
      f"{_MAKE}/sheets/packaging.py",
      f"{_MAKE}/sheets/shipping.py",
      f"{_MAKE}/sheets/overhead.py",
      f"{_MAKE}/sheets/channels.py"]),
    ("4. The six craft calculators",
     "The reason this is not a generic costing sheet. Crochet costs yarn "
     "by the gram, jewelry works in metal weight and scrap recovery, "
     "candles fill a vessel and dose the fragrance, clothing cuts fabric "
     "with a layout allowance, woodworking carries offcut waste and "
     "machine time, and a digital download spreads its design hours over "
     "the sales it expects.",
     [f"{_MAKE}/sheets/crochet.py",
      f"{_MAKE}/sheets/jewelry.py",
      f"{_MAKE}/sheets/candles.py",
      f"{_MAKE}/sheets/clothing.py",
      f"{_MAKE}/sheets/woodworking.py",
      f"{_MAKE}/sheets/digital.py"]),
    ("5. The selling registers",
     "What happens to a product once it has a price: bundles and their "
     "lines, variations and custom orders, batch production, the sales "
     "ledger, promotions, price history, competitor prices, the waste "
     "log, development cost recovery, craft fairs, stockists and "
     "wholesale orders.",
     [f"{_MAKE}/sheets/bundles.py",
      f"{_MAKE}/sheets/bundle_lines.py",
      f"{_MAKE}/sheets/variations.py",
      f"{_MAKE}/sheets/batches.py",
      f"{_MAKE}/sheets/sales.py",
      f"{_MAKE}/sheets/promotions.py",
      f"{_MAKE}/sheets/price_history.py",
      f"{_MAKE}/sheets/competitors.py",
      f"{_MAKE}/sheets/waste.py",
      f"{_MAKE}/sheets/development.py",
      f"{_MAKE}/sheets/events.py",
      f"{_MAKE}/sheets/wholesale_customers.py",
      f"{_MAKE}/sheets/wholesale_orders.py"]),
    ("6. The pages",
     "The tabs that read the registers: the welcome page, settings, the "
     "dashboard, the retail price calculator, the wholesale calculator, "
     "profit and break-even, the pricing scenarios, the reports, the "
     "three printables and the help tab.",
     [f"{_MAKE}/sheets/start_here.py",
      f"{_MAKE}/sheets/settings.py",
      f"{_MAKE}/sheets/dashboard.py",
      f"{_MAKE}/sheets/retail_calc.py",
      f"{_MAKE}/sheets/wholesale_calc.py",
      f"{_MAKE}/sheets/break_even.py",
      f"{_MAKE}/sheets/scenarios.py",
      f"{_MAKE}/sheets/reports.py",
      f"{_MAKE}/sheets/printables.py",
      f"{_MAKE}/sheets/help_tab.py"]),
    ("7. Quality checks (optional)",
     "Not needed to build the workbook - these are the checks that keep "
     "it honest. The first two need `openpyxl`, the third needs "
     "`formulas`.",
     ["tools/validate_handmade_workbook.py",
      "tools/check_handmade_sample.py",
      "tools/recalc_check.py"] + SHARED_TOOLS),
]

HANDMADE = {
    "package": "handmade_pricing_spreadsheet",
    "builder": "build_handmade_workbook.py",
    "doc": "README_HANDMADE.md",
    "tabs": 40,
    "title": "Handmade Product Pricing & Profit Calculator",
    "subtitle": ("Complete source code of the generator that writes the "
                 "`.xlsx` product."),
    "output": "SOURCE_CODE_HANDMADE.md",
    "closing": ("**Activate the first tab** and close the file - the "
                "buyer should land on Start Here, not on the Lists tab."),
    "engine_heading": "Ranking columns instead of a hidden engine",
    "intro": [
        "Writes a 40 tab `.xlsx` workbook with over 97,000 formulas: a "
        "product catalog, a material library costed to four decimal "
        "places, a bill of materials, labour by the minute, packaging "
        "profiles, a postage rate card, overhead allocation, an editable "
        "marketplace fee table, a retail price calculator, a wholesale "
        "calculator, profit and break-even, six craft specific "
        "calculators (crochet, jewelry, candles, clothing, woodworking "
        "and digital downloads), bundles, variations, batch production, "
        "a sales ledger with estimated against actual fees, promotions, "
        "price history, competitor research, a waste log, development "
        "cost recovery, craft fairs, stockists, wholesale orders, "
        "pricing scenarios, reports, three printables and a help tab. "
        "Document author is **Novality Store**; every formula cell is "
        "locked and every sheet protected with the password "
        "**`premium`**, while the cells you are meant to type in stay "
        "open.",
        "",
        "The pricing is the point: cost is materials plus labour plus "
        "packaging plus postage plus overhead, and the price is "
        "`(cost + fixed fees) / (1 - target margin - fee rate)` - a "
        "division, not an addition, so the marketplace percentage comes "
        "out of the price rather than out of your profit.",
        "",
        "Pure Python, one dependency. Tested on XlsxWriter 3.2.0 and on "
        "the much older 0.3.0, so it does not rely on anything recent. "
        "The workbook itself is Excel 2010 safe \u2014 no dynamic arrays, "
        "no `XLOOKUP`, no `IFS`, nothing that needs array entry \u2014 and "
        "it opens in Google Sheets, LibreOffice and Numbers.",
        "",
        "```bash",
        "python build_handmade_workbook.py --help",
        "",
        "  -o, --output PATH     where to write the file",
        "  --blank               no example data, just the empty workbook",
        "  --no-protect          leave the sheets unlocked",
        "  --password TEXT       protection password (default: premium)",
        "  --author TEXT         document author  (default: Novality Store)",
        "  --shop TEXT           shop name on the cover and printables",
        "  --owner TEXT          the maker's name",
        "  --currency SYMBOL     currency symbol  (default: $)",
        "  --currency-code CODE  three letter code (default: USD)",
        "  --year YYYY           the year the reports open on",
        "  --rate AMOUNT         what you pay yourself an hour",
        "  --margin PERCENT      target retail margin",
        "  --wholesale PERCENT   the discount a stockist gets off retail",
        "  --overhead AMOUNT     overhead a month, if you would rather",
        "                        type it than list it",
        "  --hours N             productive hours a month",
        "  --rounding RULE       how a calculated price is rounded",
        "  --rows N              rows of capacity in the big registers",
        "  --today YYYY-MM-DD    pretend it is this date (for the demo data)",
        "```",
    ],
    "sections": HANDMADE_SECTIONS,
}


# ---------------------------------------------------------------------------
# Product G - salon business management spreadsheet
# ---------------------------------------------------------------------------

_SALON = "salon_business_spreadsheet"

SALON_SECTIONS = [
    ("1. Run it",
     "Save the files below keeping these exact paths, then run the one "
     "liner. Nothing else is needed - no project file, no build step.\n\n"
     "```bash\n"
     "pip install XlsxWriter\n"
     "python build_salon_workbook.py\n"
     "```\n\n"
     "The workbook lands in "
     "`output/Salon Business Management Spreadsheet.xlsx`.",
     ["build_salon_workbook.py"]),
    ("2. The package",
     "Configuration, the formula template engine, cell formats, the "
     "sheet writer, the cross sheet names and the demo salon. These are "
     "the parts every tab leans on.",
     [f"{_SALON}/__init__.py",
      f"{_SALON}/__main__.py",
      f"{_SALON}/cli.py",
      f"{_SALON}/config.py",
      f"{_SALON}/layout.py",
      f"{_SALON}/formats.py",
      f"{_SALON}/writer.py",
      f"{_SALON}/names.py",
      f"{_SALON}/build.py",
      f"{_SALON}/sample_data.py"]),
    ("3. The diary and the client book",
     "The menu with its minutes and its product cost, the client "
     "record that remembers the formula and the patch test, and the "
     "appointment planner with the double-booking alarm. The shared "
     "helpers in `common.py` are where the alert colours, the lookups "
     "and the rounding rules live.",
     [f"{_SALON}/sheets/__init__.py",
      f"{_SALON}/sheets/common.py",
      f"{_SALON}/sheets/services.py",
      f"{_SALON}/sheets/clients.py",
      f"{_SALON}/sheets/appointments.py"]),
    ("4. The money",
     "The till and the payments against it. Net sale is gross less "
     "discounts less refunds; a deposit is held against the booking and "
     "applied to the first line of that visit, so it can never be "
     "counted as revenue twice.",
     [f"{_SALON}/sheets/sales.py",
      f"{_SALON}/sheets/payments.py"]),
    ("5. The team and what they are paid",
     "Eight commission methods, chosen per person, and a payroll tab "
     "that knows the difference between what somebody is paid and what "
     "they cost.",
     [f"{_SALON}/sheets/staff.py",
      f"{_SALON}/sheets/commissions.py",
      f"{_SALON}/sheets/payroll.py"]),
    ("6. Costs, stock and suppliers",
     "Every bill with its recurring frequency spread into a monthly "
     "overhead, the stock room counted the honest way, and the orders "
     "that fill it - including the column that catches a wholesaler's "
     "quiet price rise.",
     [f"{_SALON}/sheets/expenses.py",
      f"{_SALON}/sheets/inventory.py",
      f"{_SALON}/sheets/purchases.py"]),
    ("7. Growth",
     "Campaigns measured against what they really cost - the money out "
     "and the discount given away - and a loyalty scheme whose points "
     "come from spend already logged.",
     [f"{_SALON}/sheets/marketing.py",
      f"{_SALON}/sheets/loyalty.py"]),
    ("8. The pages",
     "The hand-built tabs: the welcome, the dashboard, the profit and "
     "loss, the goals and budget, the analytics, the weekly and monthly "
     "reports, and the settings tab that every formula reads.",
     [f"{_SALON}/sheets/start_here.py",
      f"{_SALON}/sheets/dashboard.py",
      f"{_SALON}/sheets/profit_loss.py",
      f"{_SALON}/sheets/goals.py",
      f"{_SALON}/sheets/analytics.py",
      f"{_SALON}/sheets/reports.py",
      f"{_SALON}/sheets/settings.py"]),
    ("9. The quality tools",
     "Not shipped with the workbook, but the reason it can be trusted: "
     "a static validator, a bracket and placeholder checker, a demo "
     "data checker that rebuilds the arithmetic in Python, and a "
     "recalculation harness that really evaluates every formula.",
     ["tools/validate_salon_workbook.py",
      "tools/check_parens.py",
      "tools/check_salon_sample.py",
      "tools/recalc_check.py"]),
]

SALON = {
    "package": _SALON,
    "builder": "build_salon_workbook.py",
    "doc": "README_SALON.md",
    "tabs": 20,
    "title": "Salon Business Management Spreadsheet",
    "subtitle": ("Complete source code of the generator that writes the "
                 "`.xlsx` product."),
    "output": "SOURCE_CODE_SALON.md",
    "closing": ("**Activate the first tab** and close the file - the "
                "buyer should land on Start Here, not on Settings."),
    "engine_heading": "Ranking columns instead of a hidden engine",
    "intro": [
        "Writes a 20 tab `.xlsx` workbook with over 122,000 formulas: an "
        "appointment planner with a double-booking alarm, a client CRM "
        "that knows who is drifting away, a service menu priced by the "
        "chair hour, a till that separates service from retail, "
        "deposits that cannot be counted twice, eight different "
        "commission methods, payroll with employer costs, expenses with "
        "recurring bills spread into a real monthly overhead, a twelve "
        "month profit and loss, stock and purchasing with reorder "
        "alerts, campaigns measured against the discount they gave "
        "away, a loyalty scheme, goals and budgets, analytics by "
        "category, day, hour and source, and printable weekly and "
        "monthly reports. Document author is **Novality Store**; every "
        "formula cell is locked and every sheet protected with the "
        "password **`premium`**, while the cells you are meant to type "
        "in stay open.",
        "",
        "Nothing is hard coded to one country or one pay model. The tax "
        "rate and the two switches that say what it applies to, the "
        "commission basis, the deposit rule, the rounding rule, the "
        "loyalty scheme and every drop-down list are settings, not "
        "assumptions.",
        "",
        "Pure Python, one dependency. Tested on XlsxWriter 3.2.0 and on "
        "the much older 0.3.0, so it does not rely on anything recent. "
        "The workbook itself is Excel 2010 safe \u2014 no dynamic "
        "arrays, no `XLOOKUP`, no `IFS`, nothing that needs array entry "
        "\u2014 and it opens in Google Sheets, LibreOffice and Numbers.",
        "",
        "```bash",
        "python build_salon_workbook.py --help",
        "",
        "  -o, --output PATH     where to write the file",
        "  --blank               no example data, just the empty workbook",
        "  --no-protect          leave the sheets unlocked",
        "  --password TEXT       protection password (default: premium)",
        "  --author TEXT         document author  (default: Novality Store)",
        "  --salon TEXT          salon name on the cover and the reports",
        "  --owner TEXT          the owner's name",
        "  --currency SYMBOL     currency symbol  (default: $)",
        "  --currency-code CODE  three letter code (default: USD)",
        "  --tax PERCENT         sales tax / VAT rate",
        "  --tax-on WHAT         both, retail, services or neither",
        "  --commission PERCENT  default service commission",
        "  --commission-method   the method new stylists start on",
        "  --hourly AMOUNT       default hourly rate",
        "  --burden PERCENT      employer costs on top of wages",
        "  --deposit PERCENT     deposit as a share of the price",
        "  --chairs N            chairs or stations in the salon",
        "  --open-days N         trading days a week",
        "  --target AMOUNT       monthly revenue target",
        "  --rows N              rows of capacity in the big registers",
        "  --today YYYY-MM-DD    pretend it is this date (for the demo data)",
        "```",
    ],
    "sections": SALON_SECTIONS,
}

# ---------------------------------------------------------------------------
# Product H - daycare & childcare business management spreadsheet
# ---------------------------------------------------------------------------

_DAYCARE = "daycare_business_spreadsheet"

DAYCARE_SECTIONS = [
    ("1. Run it",
     "Save the files below keeping these exact paths, then run the one "
     "liner. Nothing else is needed - no project file, no build step.\n\n"
     "```bash\n"
     "pip install XlsxWriter\n"
     "python build_daycare_workbook.py\n"
     "```\n\n"
     "The workbook lands in "
     "`output/Daycare Business Management Spreadsheet.xlsx`.",
     ["build_daycare_workbook.py"]),
    ("2. The package",
     "Configuration, the formula template engine, cell formats, the "
     "sheet writer, the cross sheet names and the demo nursery. These "
     "are the parts every tab leans on. `config.py` is also where the "
     "age bands and the staff-to-child ratios start out, so a setting "
     "in any country can be matched without touching a formula.",
     [f"{_DAYCARE}/__init__.py",
      f"{_DAYCARE}/__main__.py",
      f"{_DAYCARE}/cli.py",
      f"{_DAYCARE}/config.py",
      f"{_DAYCARE}/layout.py",
      f"{_DAYCARE}/formats.py",
      f"{_DAYCARE}/writer.py",
      f"{_DAYCARE}/names.py",
      f"{_DAYCARE}/build.py",
      f"{_DAYCARE}/sample_data.py"]),
    ("3. The children and the families",
     "The enrolment record that works out an age in months, drops a "
     "child into an age band, counts the siblings in a family and "
     "turns any billing basis into a weekly figure; the family record "
     "that carries one balance for several children; and the waiting "
     "list with its queue position. The shared helpers in `common.py` "
     "are where the alert colours, the lookups and the sequence keys "
     "live.",
     [f"{_DAYCARE}/sheets/__init__.py",
      f"{_DAYCARE}/sheets/common.py",
      f"{_DAYCARE}/sheets/children.py",
      f"{_DAYCARE}/sheets/parents.py",
      f"{_DAYCARE}/sheets/waitlist.py"]),
    ("4. The register",
     "Check in, check out, who collected them and whether that person "
     "was on the authorised list. Late arrivals, early pickups, "
     "missing check-outs and the late collection charge all fall out "
     "of the two time columns.",
     [f"{_DAYCARE}/sheets/attendance.py"]),
    ("5. The money",
     "Charges first, invoices second. Every fee is a line on Tuition & "
     "Fees - tuition, registration, meals, transport, late pickup, "
     "discounts and subsidies - and an invoice is simply the sum of "
     "the lines pointed at it. Payments, credit notes, refunds and "
     "write-offs sit in the same ledger, so billed and collected can "
     "never drift apart.",
     [f"{_DAYCARE}/sheets/tuition.py",
      f"{_DAYCARE}/sheets/invoices.py",
      f"{_DAYCARE}/sheets/expenses.py"]),
    ("6. The day a parent reads about",
     "The daily report, the meal log that knows the child's diet and "
     "allergy level, the medical and medication record, and the "
     "incident form with the clock running from the accident to the "
     "moment a parent was told.",
     [f"{_DAYCARE}/sheets/daily_reports.py",
      f"{_DAYCARE}/sheets/meals.py",
      f"{_DAYCARE}/sheets/medical.py",
      f"{_DAYCARE}/sheets/incidents.py"]),
    ("7. The team",
     "Staff records with four certificate expiry dates rolled into one "
     "countdown, a rota that catches a double shift and splits basic "
     "from overtime hour by hour, and a payroll tab that knows the "
     "difference between what somebody is paid and what they cost.",
     [f"{_DAYCARE}/sheets/staff.py",
      f"{_DAYCARE}/sheets/schedule.py",
      f"{_DAYCARE}/sheets/payroll.py"]),
    ("8. Rooms, stock and paperwork",
     "Occupancy and empty seats per room, the live staff-to-child "
     "ratio against the band that room is set to, the stock cupboard "
     "counted the honest way, the parent conversation log and the "
     "document tracker that watches every renewal date in the "
     "building.",
     [f"{_DAYCARE}/sheets/classrooms.py",
      f"{_DAYCARE}/sheets/supplies.py",
      f"{_DAYCARE}/sheets/communication.py",
      f"{_DAYCARE}/sheets/documents.py"]),
    ("9. The pages",
     "The hand-built tabs: the dashboard, the welcome, the settings "
     "tab every formula reads, the monthly report with its printable "
     "invoice, and the annual report.",
     [f"{_DAYCARE}/sheets/dashboard.py",
      f"{_DAYCARE}/sheets/getting_started.py",
      f"{_DAYCARE}/sheets/settings.py",
      f"{_DAYCARE}/sheets/monthly.py",
      f"{_DAYCARE}/sheets/annual.py"]),
    ("10. The quality tools",
     "Not shipped with the workbook, but the reason it can be trusted: "
     "a static validator, a bracket and placeholder checker, a demo "
     "data checker that rebuilds the arithmetic in Python, and a "
     "recalculation harness that really evaluates every formula.",
     ["tools/validate_daycare_workbook.py",
      "tools/check_parens.py",
      "tools/check_daycare_sample.py",
      "tools/recalc_check.py"]),
]

DAYCARE = {
    "package": _DAYCARE,
    "builder": "build_daycare_workbook.py",
    "doc": "README_DAYCARE.md",
    "tabs": 23,
    "title": "Daycare & Childcare Business Management Spreadsheet",
    "subtitle": ("Complete source code of the generator that writes the "
                 "`.xlsx` product."),
    "output": "SOURCE_CODE_DAYCARE.md",
    "closing": ("**Activate the first tab** and close the file - the "
                "buyer should land on the Dashboard, not on Settings."),
    "engine_heading": "Ranking columns instead of a hidden engine",
    "intro": [
        "Writes a 23 tab `.xlsx` workbook with over 143,000 formulas: "
        "enrolment with automatic child IDs, an age in months and an "
        "age band; families that hold several children and one "
        "balance; a waiting list with a queue position; a daily "
        "register with late arrivals, missing check-outs and an "
        "authorised-pickup check; tuition on six different billing "
        "bases with sibling discounts and subsidies; a charge ledger "
        "that adds up into printable invoices and receipts; daily "
        "reports, meals, allergies and medication, incident forms; "
        "staff with certificate countdowns, a rota that catches a "
        "double shift, payroll with employer costs; room occupancy "
        "with a live staff-to-child ratio alert; expenses, supplies, "
        "parent conversations and a document renewal tracker; and "
        "monthly and annual reports. Document author is **Novality "
        "Store**; every formula cell is locked and every sheet "
        "protected with the password **`premium`**, while the cells "
        "you are meant to type in stay open.",
        "",
        "Nothing is hard coded to one country's licensing. The age "
        "bands, the adults each band needs and the maximum group size "
        "are a table on Settings, so a setting in Ohio, Ontario or "
        "Oxfordshire types in its own rules and every ratio alert in "
        "the workbook follows. The tax rate and the two switches that "
        "say what it applies to, the fees, the late pickup charge, the "
        "overtime threshold and every drop-down list are settings, not "
        "assumptions.",
        "",
        "Pure Python, one dependency. Tested on XlsxWriter 3.2.0 and "
        "on the much older 0.3.0, so it does not rely on anything "
        "recent. The workbook itself is Excel 2010 safe \u2014 no "
        "dynamic arrays, no `XLOOKUP`, no `IFS`, nothing that needs "
        "array entry \u2014 and it opens in Google Sheets, LibreOffice "
        "and Numbers.",
        "",
        "```bash",
        "python build_daycare_workbook.py --help",
        "",
        "  -o, --output PATH     where to write the file",
        "  --blank               no example data, just the empty workbook",
        "  --no-protect          leave the sheets unlocked",
        "  --password TEXT       protection password (default: premium)",
        "  --author TEXT         document author  (default: Novality Store)",
        "  --centre TEXT         your setting's name on the cover",
        "  --owner TEXT          the owner or director's name",
        "  --currency SYMBOL     currency symbol  (default: $)",
        "  --currency-code CODE  three letter code (default: USD)",
        "  --tax PERCENT         tax rate, if childcare is taxed near you",
        "  --tax-on WHAT         both, tuition, extras or neither",
        "  --capacity N          licensed places for the whole setting",
        "  --open-days N         days open a week",
        "  --open-hour N         opening time, e.g. 7 for 7am",
        "  --close-hour N        closing time, e.g. 18 for 6pm",
        "  --weeks-open N        trading weeks a year",
        "  --full-time-week AMT  the standard full-time weekly fee",
        "  --basis TEXT          the billing basis new children start on",
        "  --sibling-discount P  sibling discount as a percentage",
        "  --hourly AMOUNT       default staff hourly rate",
        "  --burden PERCENT      employer costs on top of wages",
        "  --overtime-after N    hours a week before overtime starts",
        "  --target AMOUNT       monthly revenue target",
        "  --rows N              rows of capacity in the big registers",
        "  --today YYYY-MM-DD    pretend it is this date (for the demo data)",
        "```",
    ],
    "sections": DAYCARE_SECTIONS,
}


_AIRBNB = "airbnb_rental_spreadsheet"

AIRBNB_SECTIONS = [
    ("1. Run it",
     "Save the files below keeping these exact paths, then run the one "
     "liner. Nothing else is needed - no project file, no build step.\n\n"
     "```bash\n"
     "pip install XlsxWriter\n"
     "python build_airbnb_workbook.py\n"
     "```\n\n"
     "The workbook lands in "
     "`output/Airbnb & Short-Term Rental Management Spreadsheet.xlsx`.",
     ["build_airbnb_workbook.py"]),
    ("2. The package",
     "Configuration, the formula template engine, cell formats, the "
     "sheet writer, the cross sheet names and the demo portfolio. "
     "These are the parts every tab leans on. `config.py` is also "
     "where the platform fee table starts out, so a host on any "
     "platform, in any market, on any commission deal can be matched "
     "without touching a formula.",
     [f"{_AIRBNB}/__init__.py",
      f"{_AIRBNB}/__main__.py",
      f"{_AIRBNB}/cli.py",
      f"{_AIRBNB}/config.py",
      f"{_AIRBNB}/layout.py",
      f"{_AIRBNB}/formats.py",
      f"{_AIRBNB}/writer.py",
      f"{_AIRBNB}/names.py",
      f"{_AIRBNB}/build.py",
      f"{_AIRBNB}/sample_data.py"]),
    ("3. Properties and bookings",
     "The two registers everything else joins to. A property carries "
     "its own rate, fees, times and ownership basis, and collects "
     "twenty-odd calculated columns back from the rest of the "
     "workbook - occupancy, ADR, RevPAR, profit, margin and its rank "
     "in the portfolio. A booking turns two dates into nights, looks "
     "up the nightly rate, applies the platform's commission from the "
     "editable fee table, and flags a double booking by reading every "
     "other row on the same property. The shared helpers in "
     "`common.py` are where the alert colours, the ID lookups and the "
     "never-blank numeric mirror columns live.",
     [f"{_AIRBNB}/sheets/__init__.py",
      f"{_AIRBNB}/sheets/common.py",
      f"{_AIRBNB}/sheets/properties.py",
      f"{_AIRBNB}/sheets/bookings.py",
      f"{_AIRBNB}/sheets/guests.py"]),
    ("4. The calendar",
     "A month grid and a fourteen day strip across twelve properties, "
     "both drawn entirely from the Booking Tracker. No second "
     "calendar is kept, so nothing can fall out of step: an owner "
     "stay or a maintenance closure is a booking row with a block "
     "status, and the grid reads it like any other. The same page "
     "carries the Turnover Command Centre.",
     [f"{_AIRBNB}/sheets/calendar.py"]),
    ("5. The turnover",
     "What happens between one guest leaving and the next arriving. "
     "A cleaning job is generated from a check-out rather than typed "
     "from memory; the nine arrival steps are ticked off before a "
     "guest lands; and the printable checklist is a one page card "
     "driven by a single job ID that writes its nine report-back "
     "flags straight back into the schedule.",
     [f"{_AIRBNB}/sheets/arrivals.py",
      f"{_AIRBNB}/sheets/cleaning.py",
      f"{_AIRBNB}/sheets/turnover.py"]),
    ("6. The money",
     "Revenue first, cash second. A booking earns net revenue; a "
     "payout is what actually arrived, and the variance between the "
     "two is the column that pays for the spreadsheet. Expenses carry "
     "a tax category, a recurring frequency and a flag that stops a "
     "cleaning or maintenance cost being counted twice.",
     [f"{_AIRBNB}/sheets/payouts.py",
      f"{_AIRBNB}/sheets/expenses.py",
      f"{_AIRBNB}/sheets/tax.py"]),
    ("7. The property itself",
     "Stock counted the honest way with weeks of cover and a reorder "
     "flag, repairs with an estimate against an actual and a warranty "
     "countdown, the reviews with seven sub-ratings and a weakest "
     "category, and the cleaners and contractors with their rates, "
     "their completion scores and their insurance expiry dates.",
     [f"{_AIRBNB}/sheets/supplies.py",
      f"{_AIRBNB}/sheets/maintenance.py",
      f"{_AIRBNB}/sheets/reviews.py",
      f"{_AIRBNB}/sheets/vendors.py"]),
    ("8. The pages",
     "The hand-built tabs: the portfolio dashboard, the welcome, the "
     "settings tab every formula reads, the property-by-month "
     "performance register, and the monthly and annual reports.",
     [f"{_AIRBNB}/sheets/performance.py",
      f"{_AIRBNB}/sheets/dashboard.py",
      f"{_AIRBNB}/sheets/getting_started.py",
      f"{_AIRBNB}/sheets/settings.py",
      f"{_AIRBNB}/sheets/monthly.py",
      f"{_AIRBNB}/sheets/annual.py"]),
    ("9. The quality tools",
     "Not shipped with the workbook, but the reason it can be "
     "trusted: a static validator that also enforces three promises "
     "the listing makes, a bracket and placeholder checker, a demo "
     "data checker that runs before the file is written, and a "
     "recalculation harness that really evaluates every formula.",
     ["tools/validate_airbnb_workbook.py",
      "tools/check_parens.py",
      "tools/check_airbnb_sample.py",
      "tools/recalc_check.py"]),
]

AIRBNB = {
    "package": _AIRBNB,
    "builder": "build_airbnb_workbook.py",
    "doc": "README_AIRBNB.md",
    "tabs": 20,
    "title": "Ultimate Airbnb & Short-Term Rental Management Spreadsheet",
    "subtitle": ("Complete source code of the generator that writes the "
                 "`.xlsx` product."),
    "output": "SOURCE_CODE_AIRBNB.md",
    "closing": ("**Activate the first tab** and close the file - the "
                "buyer should land on the Dashboard, not on Settings."),
    "engine_heading": "Ranking columns instead of a hidden engine",
    "intro": [
        "Writes a 20 tab `.xlsx` workbook with over 138,000 formulas "
        "for an Airbnb, Vrbo or Booking.com host running more than "
        "one property: a property register with automatic IDs, rates, "
        "fees and ownership basis; a booking tracker that turns two "
        "dates into nights, looks up the nightly rate, applies the "
        "right platform commission and flags a double booking before "
        "a guest finds it; a formula-driven calendar showing one "
        "property by month or twelve properties over a fortnight; a "
        "guest CRM with repeat-stay history; the nine arrival steps; "
        "a cleaning schedule generated from the check-outs with a "
        "printable turnover checklist; expected payouts against what "
        "the platform really paid; 28 expense categories including "
        "mortgage interest and rent; supplies with low-stock flags; "
        "maintenance with warranty countdowns; reviews with seven "
        "sub-ratings; cleaners and contractors; a tax summary; "
        "occupancy, ADR and RevPAR by property and month; and "
        "monthly and annual reports. Document author is **Novality "
        "Store**; every formula cell is locked and every sheet "
        "protected with the password **`premium`**, while the cells "
        "you are meant to type in stay open.",
        "",
        "Nothing is hard coded to one platform's pricing. The eight "
        "platforms, their commission and their payment-processing "
        "rates are a table on Settings with two spare rows, so a host "
        "on a different split, in a different market or on a "
        "negotiated deal types in their own figures and every fee, "
        "payout and profit figure in the workbook follows. The "
        "lodging tax and who remits it, the turnover costs, the "
        "targets, the alert windows and every drop-down list are "
        "settings, not assumptions.",
        "",
        "Two things it refuses to do, both deliberately. It never "
        "claims to synchronise with a booking platform - there is no "
        "iCal, no API and no live feed, and the workbook says so on "
        "the Getting Started tab. And **ADR and RevPAR exclude the "
        "cleaning fee**, because including it is the most common "
        "error in rental spreadsheets sold online and it flatters "
        "both numbers; the validator fails the build if either "
        "formula so much as mentions cleaning.",
        "",
        "Pure Python, one dependency. Tested on XlsxWriter 3.2.0 and "
        "on the much older 0.3.0, so it does not rely on anything "
        "recent. The workbook itself is Excel 2010 safe \u2014 no "
        "dynamic arrays, no `XLOOKUP`, no `IFS`, nothing that needs "
        "array entry \u2014 and it opens in Google Sheets, "
        "LibreOffice and Numbers.",
        "",
        "```bash",
        "python build_airbnb_workbook.py --help",
        "",
        "  -o, --output PATH     where to write the file",
        "  --blank               no example data, just the empty workbook",
        "  --no-protect          leave the sheets unlocked",
        "  --password TEXT       protection password (default: premium)",
        "  --author TEXT         document author  (default: Novality Store)",
        "  --business TEXT       your business name on the cover",
        "  --owner TEXT          the host or owner's name",
        "  --currency SYMBOL     currency symbol  (default: $)",
        "  --currency-code CODE  three letter code (default: USD)",
        "  --nightly AMOUNT      the default nightly rate",
        "  --cleaning-fee AMT    the cleaning fee charged to a guest",
        "  --cleaning-cost AMT   what a turnover actually costs you",
        "  --deposit AMOUNT      the security deposit",
        "  --min-nights N        the default minimum stay",
        "  --tax PERCENT         lodging / occupancy tax rate",
        "  --tax-self            you remit the lodging tax, not the platform",
        "  --occupancy-target P  the occupancy you are aiming at",
        "  --adr-target AMOUNT   the average daily rate you are aiming at",
        "  --revenue-target AMT  monthly revenue target",
        "  --properties N        properties the targets are scaled for",
        "  --rows N              rows of capacity in the big registers",
        "  --today YYYY-MM-DD    pretend it is this date (for the demo data)",
        "```",
    ],
    "sections": AIRBNB_SECTIONS,
}


_WED = "wedding_photography_spreadsheet"

WEDDING_SECTIONS = [
    ("1. Run it",
     "Save the files below keeping these exact paths, then run the one "
     "liner. Nothing else is needed - no project file, no build step.\n\n"
     "```bash\n"
     "pip install XlsxWriter\n"
     "python build_wedding_workbook.py\n"
     "```\n\n"
     "The workbook lands in "
     "`output/Wedding Photographer Business Manager.xlsx`.",
     ["build_wedding_workbook.py"]),
    ("2. The package",
     "Configuration, the formula template engine, cell formats, the "
     "sheet writer, the cross sheet names and the worked example. "
     "These are the parts every tab leans on. `config.py` holds every "
     "price, every turnaround promise and every disclaimer, so a "
     "photographer in another country, on another pricing model, can "
     "be matched without touching a formula.",
     [f"{_WED}/__init__.py",
      f"{_WED}/__main__.py",
      f"{_WED}/cli.py",
      f"{_WED}/config.py",
      f"{_WED}/layout.py",
      f"{_WED}/formats.py",
      f"{_WED}/writer.py",
      f"{_WED}/names.py",
      f"{_WED}/sample_data.py",
      f"{_WED}/build.py"]),
    ("3. Shared column factories",
     "The helpers every register uses: automatic ID columns, date and "
     "month keys, ranking columns, alert conditional formats and the "
     "lookup that joins a row back to its wedding.",
     [f"{_WED}/sheets/__init__.py",
      f"{_WED}/sheets/common.py"]),
    ("4. Settings and the two front pages",
     "Settings & Lists is the only tab a buyer has to fill in before "
     "anything else works: the studio, the prices, the turnaround "
     "promises, the targets and the 48 drop-down lists. The Dashboard "
     "is the centrepiece - money, this month, the next fortnight, and "
     "a matrix that counts every alert on eleven registers. Getting "
     "Started explains the Booking ID and is honest about what the "
     "workbook is not.",
     [f"{_WED}/sheets/settings.py",
      f"{_WED}/sheets/dashboard.py",
      f"{_WED}/sheets/getting_started.py"]),
    ("5. Enquiry to confirmed booking",
     "Workflow one. The lead tracker chases an enquiry on your own "
     "schedule and reports the win rate; the client CRM holds the "
     "couple; Wedding Bookings mints the Booking ID that every other "
     "tab joins to.",
     [f"{_WED}/sheets/leads.py",
      f"{_WED}/sheets/clients.py",
      f"{_WED}/sheets/bookings.py"]),
    ("6. Package to payment collection",
     "Workflow two. What a package costs you to deliver and earns per "
     "hour, the documents that have to come back signed, and the "
     "deposit, instalments and balance with an overdue count in days.",
     [f"{_WED}/sheets/packages.py",
      f"{_WED}/sheets/contracts.py",
      f"{_WED}/sheets/payments.py"]),
    ("7. The wedding day itself",
     "Workflow three, and the part most spreadsheets skip. The "
     "timeline is built from offsets against the ceremony time, so "
     "moving the ceremony moves the day. The shot list holds the "
     "must-haves and the family groups, and the questionnaire prints "
     "them for the couple to confirm. The calendar shows twelve "
     "months of squares and turns red when two couples want the same "
     "Saturday.",
     [f"{_WED}/sheets/timeline.py",
      f"{_WED}/sheets/shots.py",
      f"{_WED}/sheets/staff.py",
      f"{_WED}/sheets/calendar.py",
      f"{_WED}/sheets/questionnaire.py"]),
    ("8. Editing to final gallery delivery",
     "Workflow four. Ten editing steps against a due date derived "
     "from the turnaround you promised, then the gallery: delivery, "
     "views, downloads, album orders, after-sales and the expiry "
     "date that is worth warning a couple about.",
     [f"{_WED}/sheets/editing.py",
      f"{_WED}/sheets/gallery.py"]),
    ("9. What each wedding actually made",
     "Workflow five. Equipment, travel, marketing and every other "
     "cost, tagged to a wedding or to the business, feeding a profit "
     "analysis that reports margin and profit per hour - then the "
     "reviews that bring the next booking, and the monthly and "
     "annual reports.",
     [f"{_WED}/sheets/equipment.py",
      f"{_WED}/sheets/travel.py",
      f"{_WED}/sheets/marketing.py",
      f"{_WED}/sheets/expenses.py",
      f"{_WED}/sheets/profit.py",
      f"{_WED}/sheets/reviews.py",
      f"{_WED}/sheets/reports.py"]),
    ("10. The quality tools",
     "Not shipped with the workbook, but the reason it can be "
     "trusted: a static validator that checks the Booking ID join in "
     "both directions and enforces the promises the listing makes, a "
     "bracket and placeholder checker, a specification checker and a "
     "sample data checker that both run before the file is written, "
     "and a recalculation harness that really evaluates every "
     "formula.",
     ["tools/validate_wedding_workbook.py",
      "tools/check_parens.py",
      "tools/check_wedding_specs.py",
      "tools/check_wedding_sample.py",
      "tools/recalc_check.py"]),
]

WEDDING = {
    "package": _WED,
    "builder": "build_wedding_workbook.py",
    "doc": "README_WEDDING.md",
    "tabs": 23,
    "title": "Wedding Photographer Business Manager",
    "subtitle": ("Complete source code of the generator that writes the "
                 "`.xlsx` product."),
    "output": "SOURCE_CODE_WEDDING.md",
    "closing": ("**Activate the first tab** and close the file - the "
                "buyer should land on the Dashboard, not on Settings."),
    "engine_heading": "Ranking columns instead of a hidden engine",
    "intro": [
        "Writes a 23 tab `.xlsx` workbook with nearly 115,000 formulas "
        "for a wedding photographer: a lead tracker that chases an "
        "enquiry on your own schedule and reports the win rate; a "
        "client CRM; a booking register of 87 columns where one "
        "wedding is one row; a twelve month calendar that turns red "
        "when two couples want the same Saturday; packages costed to "
        "a profit-per-hour figure; contracts and documents tracked "
        "through to counter-signed; deposits, instalments and "
        "balances with an overdue count in days; a wedding day "
        "timeline built from offsets against the ceremony time; a "
        "shot list with must-haves, family groups and who asked for "
        "them; second shooters with rates and insurance expiry; a ten "
        "step editing workflow against the turnaround you promised; "
        "gallery delivery with views, downloads, album orders and an "
        "expiry warning; equipment with shutter counts and "
        "replacement costs; travel and mileage against the travel fee "
        "you charged; a marketing calendar that reports enquiries per "
        "post; 27 expense categories; a profit analysis per wedding; "
        "a printable client questionnaire; reviews and referrals; and "
        "monthly and annual reports. Document author is **Novality "
        "Store**; every formula cell is locked and every sheet "
        "protected with the password **`premium`**, while the cells "
        "you are meant to type in stay open.",
        "",
        "One technical decision holds the product together: **every "
        "wedding gets a unique Booking ID** (`WED-0001`), generated "
        "once on Wedding Bookings and chosen from a drop-down "
        "everywhere else. Eleven registers join back through it, so "
        "the payment, the timeline, the shot list, the editing job "
        "and the gallery are all demonstrably the same wedding. The "
        "validator checks that join in both directions on every "
        "build, because a Booking ID that can be mistyped is a "
        "spreadsheet full of quietly disconnected records.",
        "",
        "Nothing is hard coded. The deposit percentage, the payment "
        "schedule, the extra hour rate, what a second shooter costs, "
        "the mileage rate and the free mileage allowance, the editing "
        "hours and rate, what your own hour is worth, the preview, "
        "gallery and album turnarounds, the tax rate and whether tax "
        "applies at all, every target and every alert window and all "
        "48 drop-down lists are settings, not assumptions.",
        "",
        "Two things it refuses to do, both deliberately. It never "
        "claims to connect to a booking platform or a calendar "
        "service - you type what happened and the formulas do the "
        "arithmetic - and it **tracks documents rather than "
        "pretending to generate legally binding contracts**. The "
        "Getting Started tab says both in plain words and the "
        "validator fails the build if any cell claims otherwise.",
        "",
        "Pure Python, one dependency. Tested on XlsxWriter 3.2.0 and "
        "on the much older 0.3.0, so it does not rely on anything "
        "recent. The workbook itself is Excel 2010 safe \u2014 no "
        "dynamic arrays, no `XLOOKUP`, no `IFS`, nothing that needs "
        "array entry \u2014 and it opens in Google Sheets, "
        "LibreOffice and Numbers.",
        "",
        "```bash",
        "python build_wedding_workbook.py --help",
        "",
        "  -o, --output PATH     where to write the file",
        "  --blank               no example data, just the empty workbook",
        "  --no-protect          leave the sheets unlocked",
        "  --password TEXT       protection password (default: premium)",
        "  --author TEXT         document author  (default: Novality Store)",
        "  --studio TEXT         your studio name on the cover",
        "  --owner TEXT          the photographer's name",
        "  --currency SYMBOL     currency symbol  (default: $)",
        "  --currency-code CODE  three letter code (default: USD)",
        "  --deposit PERCENT     the deposit that holds a date",
        "  --final-days N        days before the wedding the balance is due",
        "  --extra-hour AMOUNT   the charge for an extra hour on the day",
        "  --second-shooter AMT  what a second shooter costs you",
        "  --mileage RATE        the mileage rate per mile",
        "  --delivery-days N     the gallery turnaround you promise",
        "  --editing-hours N     honest editing hours per wedding",
        "  --tax PERCENT         sales tax or VAT on packages",
        "  --weddings-target N   how many weddings a year you want",
        "  --revenue-target AMT  revenue target for the year",
        "  --margin-target P     the profit margin you are aiming at",
        "  --rows N              rows of capacity in the big registers",
        "  --today YYYY-MM-DD    pretend it is this date (for the example)",
        "```",
    ],
    "sections": WEDDING_SECTIONS,
}


_INV = "inventory_wholesale_spreadsheet"

INVENTORY_SECTIONS = [
    ("1. Run it",
     "Save the files below keeping these exact paths, then run the one "
     "liner. Nothing else is needed - no project file, no build step.\n\n"
     "```bash\n"
     "pip install XlsxWriter\n"
     "python build_inventory_workbook.py\n"
     "```\n\n"
     "The workbook lands in "
     "`output/Ultimate Inventory & Wholesale Order Manager.xlsx`.",
     ["build_inventory_workbook.py"]),
    ("2. The package",
     "Configuration, the formula template engine, cell formats, the "
     "sheet writer, the cross sheet names and the worked example. "
     "These are the parts every tab leans on. `config.py` holds every "
     "price break, every status set, every alert threshold and every "
     "disclaimer, so a candle maker, a boutique and a wholesale "
     "distributor can all be matched without touching a formula.",
     [f"{_INV}/__init__.py",
      f"{_INV}/__main__.py",
      f"{_INV}/cli.py",
      f"{_INV}/config.py",
      f"{_INV}/layout.py",
      f"{_INV}/formats.py",
      f"{_INV}/writer.py",
      f"{_INV}/names.py",
      f"{_INV}/sample_data.py",
      f"{_INV}/build.py"]),
    ("3. Shared column factories",
     "The helpers every register uses: automatic ID columns, date and "
     "month keys, ranking columns, alert conditional formats, the "
     "status-set tests that decide what counts as reserved or "
     "shipped, and the weighted average cost lookup that every "
     "margin in the workbook is measured against.",
     [f"{_INV}/sheets/__init__.py",
      f"{_INV}/sheets/common.py"]),
    ("4. Settings and the two front pages",
     "Settings & Lists is the only tab a buyer has to fill in before "
     "anything else works: the business, the markup and margin floor, "
     "the lead time and safety stock, the selling fees, the targets "
     "and the 40 drop-down lists. The Dashboard is the centrepiece - "
     "stock value, what is out of stock, what needs ordering, what is "
     "reserved and unpicked, what is late, and a matrix that counts "
     "every alert on seventeen registers. Getting Started explains "
     "the SKU and is honest about what the workbook is not.",
     [f"{_INV}/sheets/settings.py",
      f"{_INV}/sheets/dashboard.py",
      f"{_INV}/sheets/getting_started.py"]),
    ("5. Product, SKU and stock",
     "Workflow one, and the decision the rest of the product rests "
     "on. The catalogue mints a Product ID and flags a SKU entered "
     "twice. The Inventory Tracker holds no typed numbers at all: "
     "every figure on it is derived from the transaction registers, "
     "and reserved stock is kept separate from available stock so a "
     "confirmed order cannot be sold twice. The Stock Movement Log "
     "records the things that are not purchases, sales or returns - "
     "damage, loss, samples, production use, transfers - and keeps "
     "manual corrections in their own audited column.",
     [f"{_INV}/sheets/products.py",
      f"{_INV}/sheets/inventory.py",
      f"{_INV}/sheets/movements.py"]),
    ("6. Supplier, purchase order, receiving",
     "Workflow two. Suppliers are scored on the lead time they "
     "actually deliver against the one they quote. Purchase orders "
     "carry freight into a landed cost per unit, track part "
     "deliveries line by line, compare the invoice to the order, and "
     "refuse to let the same PO line be received twice without "
     "saying so.",
     [f"{_INV}/sheets/suppliers.py",
      f"{_INV}/sheets/purchases.py"]),
    ("7. Wholesale customer, tiered price, fulfilment",
     "Workflow three, and the half of this product its competitors "
     "do not have. A trade CRM with terms, credit limits and what "
     "each account is worth; price breaks you set yourself, checked "
     "against the weighted average cost and against your own floor "
     "price; and an order register that reserves stock on "
     "confirmation, tells you what you are short before you promise "
     "it, and ages the invoice afterwards.",
     [f"{_INV}/sheets/customers.py",
      f"{_INV}/sheets/pricing.py",
      f"{_INV}/sheets/orders.py"]),
    ("8. Sales, reordering and what the stock is worth",
     "Workflow four. Retail sales across ten channels with the "
     "marketplace and payment fees taken out, so the profit column "
     "is the money that actually arrived. The reorder planner turns "
     "the sales rate and the real lead time into a reorder point, a "
     "suggested quantity rounded to the case, and the date you have "
     "to order by. The valuation tab is the single costing method - "
     "weighted average - that every other margin in the workbook "
     "reads.",
     [f"{_INV}/sheets/retail.py",
      f"{_INV}/sheets/reorder.py",
      f"{_INV}/sheets/valuation.py"]),
    ("9. Returns, locations and counting the shelf",
     "The registers that keep the stock figure honest. Returns decide "
     "for themselves whether the unit goes back on the shelf or is "
     "written off. Locations split one SKU across bins without "
     "losing the total. The stock audit never overwrites stock: a "
     "count produces a variance, and you post the adjustment "
     "yourself, which is the only way the number stays explainable.",
     [f"{_INV}/sheets/returns.py",
      f"{_INV}/sheets/locations.py",
      f"{_INV}/sheets/audit.py"]),
    ("10. What each product actually made",
     "Workflow five. Product performance ranks the catalogue by "
     "profit, by return on stock and by how long it has been sitting "
     "there. The expense tracker keeps buying stock out of the "
     "operating total on purpose. The profit analysis puts the "
     "month-by-month picture together, and the reports and printable "
     "documents are the pages you hand to somebody else.",
     [f"{_INV}/sheets/performance.py",
      f"{_INV}/sheets/expenses.py",
      f"{_INV}/sheets/profit.py",
      f"{_INV}/sheets/monthly.py",
      f"{_INV}/sheets/annual.py",
      f"{_INV}/sheets/printables.py"]),
    ("11. The quality tools",
     "Not shipped with the workbook, but the reason it can be "
     "trusted: a static validator that checks the SKU join in both "
     "directions and holds the five technical decisions to account, "
     "a bracket and placeholder checker, a specification checker and "
     "a sample data checker that both run before the file is "
     "written, and a recalculation harness that really evaluates "
     "every formula.",
     ["tools/validate_inventory_workbook.py",
      "tools/check_parens.py",
      "tools/check_inventory_specs.py",
      "tools/check_inventory_sample.py",
      "tools/recalc_check.py"]),
]

INVENTORY = {
    "package": _INV,
    "builder": "build_inventory_workbook.py",
    "doc": "README_INVENTORY.md",
    "tabs": 23,
    "title": "Ultimate Inventory & Wholesale Order Manager",
    "subtitle": ("Complete source code of the generator that writes the "
                 "`.xlsx` product."),
    "output": "SOURCE_CODE_INVENTORY.md",
    "closing": ("**Activate the first tab** and close the file - the "
                "buyer should land on the Dashboard, not on Settings."),
    "engine_heading": "Ranking columns instead of a hidden engine",
    "intro": [
        "Writes a 23 tab `.xlsx` workbook with over 136,000 formulas "
        "for anybody who buys stock and sells it: a product database "
        "where every separately stocked variant has its own SKU; a "
        "stock tracker with nothing typed on it at all; a movement "
        "log for damage, loss, samples and transfers; suppliers "
        "scored on the lead time they actually deliver; purchase "
        "orders with landed costs, part deliveries and a "
        "duplicate-receiving guard; a wholesale CRM with terms and "
        "credit limits; price breaks you set yourself, checked "
        "against cost and against your own floor; wholesale orders "
        "that reserve stock the moment they are confirmed; retail "
        "sales across ten channels with the platform fees taken out; "
        "a reorder planner that works out the date you have to order "
        "by; weighted average valuation and COGS; returns that decide "
        "whether a unit goes back on the shelf; bin locations; stock "
        "counts that raise a variance instead of overwriting the "
        "number; profit per product; and printable purchase orders, "
        "invoices and picking lists. Document author is **Novality "
        "Store**; every formula cell is locked and every sheet "
        "protected with the password **`premium`**, while the cells "
        "you are meant to type in stay open.",
        "",
        "**Stock is derived, never typed.** The Inventory Tracker has "
        "no input columns. What you have is opening stock, plus what "
        "was received against a purchase order, minus what was sold "
        "retail and wholesale, plus what came back, minus what was "
        "damaged, plus or minus what you adjusted - and every one of "
        "those terms is a row somebody entered on another tab. A "
        "stock figure you can type over is a stock figure that has "
        "stopped meaning anything, which is how most inventory "
        "spreadsheets quietly fail in their second month.",
        "",
        "**Reserved stock is separate from available stock.** "
        "Confirming a wholesale order takes those units out of "
        "availability without pretending they have shipped, so the "
        "same ninety candles cannot be promised to two shops. The "
        "order register tells you what you are short before you "
        "promise it, not after.",
        "",
        "**One costing method, used everywhere.** Weighted average, "
        "from the opening value plus everything received, applied "
        "identically in the valuation, in the retail margin, in the "
        "wholesale line profit and in the profit-by-product ranking. "
        "Mixing methods between tabs is the most common way these "
        "workbooks produce two different answers to the same "
        "question.",
        "",
        "**Receiving twice cannot double-count.** A purchase order "
        "line that appears twice for the same SKU is flagged before "
        "the delivery is counted, because the easiest way to invent "
        "stock that does not exist is to receive the same pallet on "
        "two rows.",
        "",
        "Nothing is hard coded. The markup a new product starts at, "
        "the margin you refuse to go under, the lead time, the days "
        "of safety stock, the window the sales rate averages over, "
        "when stock counts as slow or dead, the marketplace and "
        "payment fees, the tax rate and whether tax applies at all, "
        "the three price breaks, the five customer tiers and their "
        "multipliers, every target, every alert threshold and all 40 "
        "drop-down lists are settings, not assumptions.",
        "",
        "One thing it refuses to do, deliberately. It never claims "
        "to synchronise with Etsy, Shopify, Amazon or anything else "
        "- you enter or paste your orders and the formulas do the "
        "arithmetic. The Getting Started tab says so in plain words "
        "and the validator fails the build if any cell claims "
        "otherwise.",
        "",
        "Pure Python, one dependency. Tested on XlsxWriter 3.2.0 and "
        "on the much older 0.3.0, so it does not rely on anything "
        "recent. The workbook itself is Excel 2010 safe \u2014 no "
        "dynamic arrays, no `XLOOKUP`, no `IFS`, nothing that needs "
        "array entry \u2014 and it opens in Google Sheets, "
        "LibreOffice and Numbers.",
        "",
        "```bash",
        "python build_inventory_workbook.py --help",
        "",
        "  -o, --output PATH     where to write the file",
        "  --blank               no example data, just the empty workbook",
        "  --no-protect          leave the sheets unlocked",
        "  --password TEXT       protection password (default: premium)",
        "  --author TEXT         document author  (default: Novality Store)",
        "  --business TEXT       your business name on the cover",
        "  --owner TEXT          the owner's name",
        "  --currency SYMBOL     currency symbol  (default: $)",
        "  --currency-code CODE  three letter code (default: USD)",
        "  --markup NUMBER       the markup a new product starts at",
        "  --min-margin PERCENT  the margin you refuse to go under",
        "  --lead-time DAYS      lead time when a supplier has none set",
        "  --safety-days N       days of safety stock in the reorder point",
        "  --sales-window N      days the sales rate averages over",
        "  --marketplace-fee P   marketplace commission percentage",
        "  --payment-fee P       payment processing percentage",
        "  --tax PERCENT         sales tax or VAT on sales",
        "  --revenue-target AMT  revenue target for the year",
        "  --margin-target P     the gross margin you are aiming at",
        "  --rows N              rows of capacity in the big registers",
        "  --today YYYY-MM-DD    pretend it is this date (for the example)",
        "```",
    ],
    "sections": INVENTORY_SECTIONS,
}


_LAND = "landscaping_spreadsheet"

LANDSCAPING_SECTIONS = [
    ("1. Run it",
     "Save the files below keeping these exact paths, then run the one "
     "liner. Nothing else is needed - no project file, no build step.\n\n"
     "```bash\n"
     "pip install XlsxWriter\n"
     "python build_landscaping_workbook.py\n"
     "```\n\n"
     "The workbook lands in "
     "`output/Ultimate Landscaping & Lawn Care Business Manager.xlsx`.",
     ["build_landscaping_workbook.py"]),
    ("2. The package",
     "Configuration, the formula template engine, cell formats, the "
     "sheet writer, the cross sheet names and the worked example. "
     "These are the parts every tab leans on. `config.py` holds every "
     "rate, every status set, every alert threshold and every "
     "disclaimer, so a one-truck mowing round, a landscaping "
     "contractor and a six-crew grounds maintenance firm can all be "
     "matched without touching a formula.",
     [f"{_LAND}/__init__.py",
      f"{_LAND}/__main__.py",
      f"{_LAND}/cli.py",
      f"{_LAND}/config.py",
      f"{_LAND}/layout.py",
      f"{_LAND}/formats.py",
      f"{_LAND}/writer.py",
      f"{_LAND}/names.py",
      f"{_LAND}/sample_data.py",
      f"{_LAND}/build.py"]),
    ("3. Shared column factories",
     "The helpers every register uses: automatic ID columns, date, "
     "month and week keys, ranking columns, alert conditional "
     "formats, the status-set tests that decide what counts as an "
     "open job or a live contract, and the customer, property, "
     "service and job lookups that turn an ID into a name, an "
     "address, a rate or a price.",
     [f"{_LAND}/sheets/__init__.py",
      f"{_LAND}/sheets/common.py"]),
    ("4. Settings and the two front pages",
     "Settings & Lists is the only tab a buyer has to fill in before "
     "anything else works: the business, the labour and charge-out "
     "rates, the overhead per crew hour, the target and floor "
     "margins, the minimum visit, the travel rate, the service "
     "intervals, the season, the targets and 44 drop-down lists. The "
     "Dashboard is the centrepiece - today's round, the week ahead, "
     "the work that slipped, the money owed, machines due a service, "
     "materials running out, and a matrix that counts every alert on "
     "sixteen registers. Getting Started explains the four IDs and is "
     "honest about what the workbook is not.",
     [f"{_LAND}/sheets/settings.py",
      f"{_LAND}/sheets/dashboard.py",
      f"{_LAND}/sheets/getting_started.py"]),
    ("5. Customer, property, service",
     "Workflow one, and the decision the rest of the product rests "
     "on. The CRM mints a Customer ID; the Property Database mints a "
     "Property ID and hangs it off that customer, with the lawn area, "
     "the drive time, the gate code and the dog; the Service Catalog "
     "prices the work per 1,000 sq ft, per visit, per hour or per "
     "plant, and carries the minutes each unit really takes. "
     "Everything after this joins back through those IDs.",
     [f"{_LAND}/sheets/customers.py",
      f"{_LAND}/sheets/properties.py",
      f"{_LAND}/sheets/services.py"]),
    ("6. The quote, and the work order it becomes",
     "Workflow two. The quote calculator starts from the lawn size on "
     "the property record and the minutes in the catalogue, adds "
     "labour at your cost rate, materials at your markup, equipment, "
     "two-way travel and overhead per crew hour, then works the price "
     "back off the margin you asked for and refuses to go under your "
     "minimum visit. Accept it and the Job & Work Orders register "
     "carries the same price through to the invoice, costing itself "
     "twice on the way: what you estimated, and what the timesheets "
     "and expenses say it really took.",
     [f"{_LAND}/sheets/quotes.py",
      f"{_LAND}/sheets/jobs.py",
      f"{_LAND}/sheets/route.py"]),
    ("7. The recurring round",
     "Workflow three, and the half of this product a one-off job "
     "sheet does not have. A contract carries a frequency, a visit "
     "price and a renewal date; it works out its own next visit from "
     "the last one, tells you when nothing is booked, values itself "
     "over a year and warns before it lapses. The seasonal planner "
     "turns the year into four blocks of work with the maintenance "
     "and inspection checklists the crew actually uses.",
     [f"{_LAND}/sheets/contracts.py",
      f"{_LAND}/sheets/seasonal.py"]),
    ("8. Crew, schedule and payroll hours",
     "Workflow four. The crew database holds the pay rate, the "
     "licence expiry and what each person has earned you; the "
     "schedule compares planned hours against capacity day by day; "
     "the timesheets split overtime out on a weekly running total, "
     "cost every hour at that person's rate, and hand the job its "
     "real labour cost. Gross figures for pricing, not a payroll "
     "filing - the workbook says so where you can read it.",
     [f"{_LAND}/sheets/crew.py",
      f"{_LAND}/sheets/schedule.py",
      f"{_LAND}/sheets/timesheets.py"]),
    ("9. Machines, trucks and materials",
     "Workflow five. Equipment warns twice - on engine hours since "
     "the last service and on months since it, whichever lands "
     "first - and the dashboard picks that up. The vehicle tracker "
     "works out miles per gallon from the odometer readings rather "
     "than asking you for it. Materials stock is derived from the "
     "purchases and the usage logged against jobs, so it is never a "
     "number anybody types over, and it reorders itself when it drops "
     "to the trigger level.",
     [f"{_LAND}/sheets/equipment.py",
      f"{_LAND}/sheets/vehicles.py",
      f"{_LAND}/sheets/materials.py"]),
    ("10. Getting paid, and what was left",
     "Workflow six. Invoices age from the due date rather than the "
     "invoice date, take part payments, and chase themselves. The "
     "expense tracker separates a cost that belongs to one visit from "
     "an overhead that belongs to the month. Customer feedback scores "
     "the crew and reopens the complaint until somebody closes it. "
     "Profit analysis, the monthly report and the annual report then "
     "put fourteen months of revenue, labour, materials, fuel and "
     "margin into one picture.",
     [f"{_LAND}/sheets/invoices.py",
      f"{_LAND}/sheets/expenses.py",
      f"{_LAND}/sheets/feedback.py",
      f"{_LAND}/sheets/profit.py",
      f"{_LAND}/sheets/monthly.py",
      f"{_LAND}/sheets/annual.py"]),
    ("11. The quality tools",
     "Not shipped with the workbook, but the reason it can be "
     "trusted: a static validator that checks the Customer, Property, "
     "Job and Invoice joins in both directions and holds the seven "
     "technical decisions to account, a bracket and placeholder "
     "checker, a specification checker and a sample data checker that "
     "both run before the file is written, and a recalculation "
     "harness that really evaluates every formula.",
     ["tools/validate_landscaping_workbook.py",
      "tools/check_parens.py",
      "tools/check_landscaping_specs.py",
      "tools/check_landscaping_sample.py",
      "tools/recalc_check.py"]),
]

LANDSCAPING = {
    "package": _LAND,
    "builder": "build_landscaping_workbook.py",
    "doc": "README_LANDSCAPING.md",
    "tabs": 23,
    "title": "Ultimate Landscaping & Lawn Care Business Manager",
    "subtitle": ("Complete source code of the generator that writes the "
                 "`.xlsx` product."),
    "output": "SOURCE_CODE_LANDSCAPING.md",
    "closing": ("**Activate the first tab** and close the file - the "
                "buyer should land on the Dashboard, not on Settings."),
    "engine_heading": "Ranking columns instead of a hidden engine",
    "intro": [
        "Writes a 23 tab `.xlsx` workbook with over 172,000 formulas "
        "for anybody who cuts grass for a living: a customer CRM and "
        "a property database joined by ID, with the lawn area, the "
        "drive time, the gate code and the dog; a service catalogue "
        "priced per 1,000 sq ft, per visit, per hour, per linear foot "
        "or per plant; a quote calculator that prices from the lawn "
        "size, the labour, the materials, the equipment, two-way "
        "travel and the margin you want; work orders that cost "
        "themselves twice, estimated and actual; a route planner that "
        "prints one crew's day on one sheet; recurring contracts that "
        "work out their own next visit; crew, schedule and timesheets "
        "with weekly overtime; equipment that warns on engine hours "
        "and on months; a vehicle and fuel log that works out miles "
        "per gallon from the odometer; materials stock derived from "
        "purchases and usage; invoices that age from the due date; "
        "and a profit analysis that says what every month, every "
        "service and every customer actually made. Document author "
        "is **Novality Store**; every formula cell is locked and "
        "every sheet protected with the password **`premium`**, while "
        "the cells you are meant to type in stay open.",
        "",
        "**Four IDs hold it together.** Customer ID, Property ID, Job "
        "ID and Invoice ID are generated by the workbook, never "
        "typed, and every register that refers to one picks it from a "
        "drop-down. That is the difference between a business manager "
        "and twenty-three unrelated lists in the same file: a "
        "property knows whose it is, a job knows which property and "
        "which contract it came from, an invoice knows which job it "
        "bills, and the customer's lifetime revenue falls out of the "
        "arithmetic instead of being counted by hand.",
        "",
        "**A quote is built, not guessed.** Lawn size comes off the "
        "property record, the minutes come off the catalogue, labour "
        "is costed at your rate and your crew size, materials carry "
        "your markup, travel is charged both ways, overhead is "
        "carried per crew hour - and then the price is worked back "
        "off the margin you asked for, with your minimum visit charge "
        "as the floor. Change a rate on Settings and every open quote "
        "reprices.",
        "",
        "**Every job is costed twice.** What you estimated, from the "
        "catalogue minutes and the property's difficulty factor, and "
        "what it really cost, from the hours the crew logged and the "
        "fuel, materials and disposal booked against it. The gap "
        "between those two numbers, job by job and service by "
        "service, is the thing that tells you which work to keep and "
        "which to reprice.",
        "",
        "Nothing is hard coded. The labour rate, the charge-out rate, "
        "overhead per hour, target and minimum margins, the minimum "
        "visit, the material markup, the travel rate per mile, drive "
        "time between stops, mowing minutes per 1,000 sq ft, quote "
        "validity, the service intervals in both hours and months, "
        "the season months, the dormant-customer window, every alert "
        "threshold, every target and all 44 drop-down lists are "
        "settings, not assumptions.",
        "",
        "Two things it refuses to do, deliberately. The route planner "
        "organises the stops you have chosen onto a printable sheet - "
        "it is not GPS navigation and it does not optimise a route. "
        "And nothing in the file syncs with accounting, payroll or "
        "booking software: you enter what happened and the formulas "
        "do the arithmetic. The Getting Started tab says both in "
        "plain words and the validator fails the build if any cell "
        "claims otherwise.",
        "",
        "Pure Python, one dependency. Tested on XlsxWriter 3.2.0 and "
        "on the much older 0.3.0, so it does not rely on anything "
        "recent. The workbook itself is Excel 2010 safe \u2014 no "
        "dynamic arrays, no `XLOOKUP`, no `IFS`, nothing that needs "
        "array entry \u2014 and it opens in Google Sheets, "
        "LibreOffice and Numbers.",
        "",
        "```bash",
        "python build_landscaping_workbook.py --help",
        "",
        "  -o, --output PATH     where to write the file",
        "  --blank               no example data, just the empty workbook",
        "  --rows N              rows of capacity in the big registers",
        "  --today YYYY-MM-DD    pretend it is this date (for the example)",
        "  --quiet               no progress output",
        "```",
    ],
    "sections": LANDSCAPING_SECTIONS,
}


PRODUCTS = {"pet": PET, "social": SOCIAL, "meal": MEAL,
            "cleaning": CLEANING, "handmade": HANDMADE,
            "salon": SALON, "daycare": DAYCARE,
            "airbnb": AIRBNB, "wedding": WEDDING,
            "inventory": INVENTORY,
            "landscaping": LANDSCAPING}


# ---------------------------------------------------------------------------
# Chapter 0 - how the generator is put together (same engine for both
# products, so the prose is written once and filled in per product)
# ---------------------------------------------------------------------------

ARCHITECTURE = """\
Everything here is plain Python writing a `.xlsx` file through XlsxWriter.
There is no template workbook, no copy of an existing file and no manual
step: the spreadsheet is described in code, and the code is the only
source of truth for what ends up in a cell.

Two kinds of tab exist.

* A **register** is a data tab — a header row and hundreds of rows under
  it. Its module exposes `NAME`, a `spec(cfg)` that returns a
  `SheetSpec` (a list of `Col` objects) and, optionally, a
  `decorate(sheet, fmts, cfg)` that adds totals or notes underneath the
  grid. Nothing in a register module writes cells directly.
* A **page** is a hand-built tab — the dashboards, the reports, the
  printables, the welcome and help pages. Its module exposes
  `build(book, fmts, cfg, reg)` and writes with `SheetWriter` helpers:
  `banner`, `section`, `kpi`, `table_head`, `calc_row`, `note`,
  `bullets`, `field`, `merge`, `finish`.

### The build pipeline

`{builder}` parses the command line into a `Config`, then
`{package}.build.build_workbook(path, cfg)` does six things in order:

1. **Open the workbook** and stamp the document properties — title,
   author, company, keywords and a comment naming the protection
   password. The author is the same on every generated file.
2. **Build the `FormatBook`.** Every visual style the product uses is
   created once, up front: a style (text, date, money, percent, status,
   link, …) crossed with a mode (`INPUT` cream and unlocked, `CALC` grey
   and locked, `PLAIN`), plus the page chrome (titles, section bars, KPI
   tiles, notes) and the conditional formatting palette.
3. **Register every `SheetSpec` first**, before a single tab is written.
   This is what lets any sheet refer to any other sheet's columns by
   name regardless of which tab happens to be written first.
4. **Write the tabs in `SHEET_ORDER`.** Registers go through
   `build_register()` — `SheetWriter.grid(spec)` writes widths, formats,
   headers, formulas, sample rows, drop downs, header comments,
   conditional formats, the autofilter, frozen panes and the print
   setup — then the module's `decorate()` runs and the sheet is
   protected. Pages call their own `build()`.
5. **Define the live lookup names** (`ContentIDs`, `TeamNames`, …) from
   the registry. Each is an `OFFSET` range that grows and shrinks with
   the number of filled rows, so a drop down never shows blanks.
6. {closing}

### Describing a column

A column is declared once, for one row, with placeholders:

```python
Col("er", "Engagement rate", 11, "percent",
    formula='=IFERROR({{engagements}}{{r}}/{{reach}}{{r}},"")',
    cf=[{{"type": "cell", "criteria": ">=", "value": "=TargetEngagement",
         "fmt": "good"}}])
```

`Col` carries the key, the header text, the width, the style, the
formula template, the data validation, the header comment, the
conditional formats, whether the column is hidden and which outline
group it belongs to. `Registry.render()` expands the template per row:

| Token | Becomes |
|-------|---------|
| `{{r}}` / `{{r_prev}}` | this row number / the row above |
| `{{key}}` | the column letter of another column on the same sheet |
| `{{first}}` / `{{last}}` | the first and last data row of the sheet |
| `[[Sheet.key]]` | an absolute range on another sheet, e.g. `'Content Calendar'!$G$5:$G$604` |
| `[[Sheet.key#12]]` | one cell of that column |
| `[[Sheet.key#]]` | the same row as the formula being written |

Helpers cover the patterns Excel 2010 makes awkward — `max_if`,
`min_if`, `blank_if`, `safe`, `lookup`, `dynamic_name`, `quote_sheet`.

### The rules every formula obeys

* **Excel 2010 safe.** `SUMIFS`, `COUNTIFS`, `INDEX/MATCH`, `SMALL`,
  `LARGE`, `RANK`, `EDATE`, `EOMONTH`, `SUMPRODUCT(MAX(...))`. No
  dynamic arrays, no `XLOOKUP`, no `IFS`, no `AGGREGATE`, nothing that
  needs Ctrl+Shift+Enter. The file opens in Excel 2010 and later, Google
  Sheets, LibreOffice and Numbers.
* **No charts.** The vendored XlsxWriter in this repository cannot write
  them, so trends are drawn with `add_sparkline`, data bars and
  three-colour scales — which also survive a Google Sheets import.
* **Nth-row lookups without array formulas.** Hidden composite key
  columns (`date + ROW()/100000`) plus `SMALL` and `INDEX/MATCH` answer
  "the third thing on 14 March" and "the next eight due" with ordinary
  formulas.
* **One number, one home.** Nothing is typed into two tabs. Every other
  appearance of a figure is a formula pointing back at the one place it
  was entered.
* **Locked where it matters.** Formula cells are locked, input cells are
  not, and every sheet is protected with the same password — so the
  maths cannot be typed over by accident but the cream cells stay open.

{engine}
"""

DEFAULT_CLOSING = ("**Hide the `Calc` engine**, activate the first tab "
                   "and close the file.")

CALC_ENGINE = """\
### The hidden `Calc` tab

Dashboards do not aggregate the registers directly. A hidden sheet
pre-computes one row per month, per platform/service, per category and
per owner, each with its own ranking key, and the visible pages read
those columns with plain `INDEX`/`MATCH`. It keeps the heavy `SUMIFS`
work in one place, keeps recalculation predictable, and makes every
dashboard number traceable to a single cell."""

RANK_ENGINE = """\
### Ranking columns instead of a hidden engine

There is no hidden `Calc` tab in this product. Anything a page needs to
rank - the next thing to buy, the recipe you have left alone longest,
the leftovers to eat first, the fridge item closest to its date - is a
**hidden rank column on the register itself**:

```python
Col("rotation_rank", "Rotation rank", 9, "int",
    formula='=IF({{name}}{{r}}="","",COUNTIFS({{sort_key_first}}:'
            '{{sort_key_last}},">"&{{sort_key}}{{r}})+'
            'COUNTIFS({{sort_key_first}}:{{sort_key}}{{r}},'
            '{{sort_key}}{{r}}))',
    hidden=True)
```

`COUNTIFS(whole column, ">" & this row) + COUNTIFS(up to this row, this
row)` is a dense rank that breaks ties by row order, so the ranks come
out 1, 2, 3 ... with no gaps and no duplicates. The page then asks for
the nth item with an ordinary `MATCH(n, rank_range, 0)` - a plain range
lookup, which is why there is **no array formula and nothing needing
Ctrl+Shift+Enter anywhere in the workbook**. The tempting alternative,
`LARGE(IF(...))` over a computed array, reads better in Python and
quietly returns the wrong answer in Excel 2010.

The ranks in use: `Ingredients.need_rank` (what to buy next),
`Grocery List.buy_rank` (position on the printed list),
`Ingredients.spend_rank` and `waste_rank`, `Recipes.cost_rank`,
`match_rank`, `rotation_rank`, `times_planned_rank`, `calories_rank`,
`protein_rank` and `fibre_rank`, `Pantry.fridge_rank` and
`freezer_rank`, `Leftovers.queue_rank`, `Meal Prep.todo_rank` and
`Stores.spend_rank`."""


def outline(path: str) -> list:
    """`[(kind, name, note)]` for the classes, functions and constants."""
    with open(os.path.join(ROOT, path), encoding="utf-8") as handle:
        source = handle.read()
    try:
        tree = ast.parse(source)
    except SyntaxError:                                  # pragma: no cover
        return []
    items = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            args = [a.arg for a in node.args.args]
            if node.args.vararg:
                args.append("*" + node.args.vararg.arg)
            if node.args.kwonlyargs:
                args.append("*")
                args += [a.arg for a in node.args.kwonlyargs]
            if node.args.kwarg:
                args.append("**" + node.args.kwarg.arg)
            note = first_sentence(ast.get_docstring(node) or "")
            items.append(("function", f"{node.name}({', '.join(args)})",
                          note))
        elif isinstance(node, ast.ClassDef):
            bases = []
            for base in node.bases:
                try:
                    bases.append(ast.unparse(base))
                except Exception:                        # pragma: no cover
                    pass
            name = node.name + (f"({', '.join(bases)})" if bases else "")
            note = first_sentence(ast.get_docstring(node) or "")
            fields = [n.target.id for n in node.body
                      if isinstance(n, ast.AnnAssign)
                      and isinstance(n.target, ast.Name)]
            if fields and not note:
                note = "fields: " + ", ".join(fields[:8])
            items.append(("class", name, note))
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = ([node.target] if isinstance(node, ast.AnnAssign)
                       else node.targets)
            for target in targets:
                if not isinstance(target, ast.Name):
                    continue
                if not re.match(r"^[A-Z][A-Z0-9_]*$", target.id):
                    continue
                items.append(("constant", target.id,
                              describe_value(node.value)))
    return items


def describe_value(node) -> str:
    """A short, human description of a module level constant."""
    if node is None:
        return ""
    if isinstance(node, ast.Constant):
        text = repr(node.value)
        return text if len(text) < 60 else f"{text[:57]}..."
    if isinstance(node, (ast.List, ast.Tuple)):
        return f"{len(node.elts)} items"
    if isinstance(node, ast.Dict):
        return f"{len(node.keys)} entries"
    if isinstance(node, ast.Call):
        try:
            name = ast.unparse(node.func)
        except Exception:                                # pragma: no cover
            name = "call"
        return f"{name}(...)"
    try:
        text = ast.unparse(node)
    except Exception:                                    # pragma: no cover
        return ""
    return text if len(text) < 60 else f"{text[:57]}..."


def first_sentence(text: str) -> str:
    text = " ".join(text.split())
    if not text:
        return ""
    cut = re.search(r"\.(\s|$)", text)
    if cut:
        text = text[:cut.start()]
    return text.strip().rstrip(".")


def blurb(path: str) -> str:
    """First sentence of the module docstring, as a one line description."""
    with open(os.path.join(ROOT, path), encoding="utf-8") as handle:
        source = handle.read()
    try:
        text = ast.get_docstring(ast.parse(source)) or ""
    except SyntaxError:                                  # pragma: no cover
        text = ""
    return first_sentence(text)


def full_docstring(path: str) -> str:
    with open(os.path.join(ROOT, path), encoding="utf-8") as handle:
        source = handle.read()
    try:
        return (ast.get_docstring(ast.parse(source)) or "").strip()
    except SyntaxError:                                  # pragma: no cover
        return ""


def anchor(heading: str) -> str:
    slug = heading.lower()
    slug = re.sub(r"[^\w\s-]", "", slug)
    return re.sub(r"\s+", "-", slug.strip())


def tab_table(product: dict) -> list:
    """A row per tab: order, name, kind, module, columns, rows.

    Imports the product package, so it degrades to nothing if the
    generator is not importable from where the tool is run.
    """
    if ROOT not in sys.path:
        sys.path.insert(0, ROOT)
    try:
        package = __import__(f"{product['package']}.build",
                             fromlist=["build"])
        config = __import__(f"{product['package']}.config",
                            fromlist=["config"])
    except Exception:                                    # pragma: no cover
        return []
    cfg = config.Config()
    lines = ["| # | Tab | Kind | Written by | Columns | Rows |",
             "|---|-----|------|------------|--------:|-----:|"]
    for number, name in enumerate(package.SHEET_ORDER, start=1):
        module = package.REGISTER_BY_NAME.get(name)
        if module is not None:
            spec = module.spec(cfg)
            # a register is usually a module, but the platform planners
            # are instances of one shared class
            where = (getattr(module, "__name__", None)
                     or type(module).__module__)
            path = where.replace(".", "/") + ".py"
            lines.append(f"| {number} | **{name}** | register | "
                         f"`{path}` | {len(spec.columns)} | {spec.rows} |")
        else:
            builder = package.PAGE_BUILDERS.get(name)
            path = (getattr(builder, "__module__", "")
                    .replace(".", "/") + ".py")
            lines.append(f"| {number} | **{name}** | page | `{path}` "
                         f"| - | - |")
    return lines


def data_dictionary(product: dict) -> list:
    """One table per register: every column, its type and where it comes
    from. Generated from the specs themselves, so it cannot drift."""
    if ROOT not in sys.path:
        sys.path.insert(0, ROOT)
    try:
        package = __import__(f"{product['package']}.build",
                             fromlist=["build"])
        config = __import__(f"{product['package']}.config",
                            fromlist=["config"])
    except Exception:                                    # pragma: no cover
        return []
    cfg = config.Config()
    lines = []
    for name in package.SHEET_ORDER:
        module = package.REGISTER_BY_NAME.get(name)
        if module is None:
            continue
        spec = module.spec(cfg)
        typed = sum(1 for c in spec.columns if not c.is_formula)
        lines += [f"#### {spec.name}", ""]
        if spec.subtitle:
            lines += [f"{spec.subtitle}", ""]
        lines += [f"{len(spec.columns)} columns, {spec.rows} rows of "
                  f"capacity, {typed} of them typed in by hand.", "",
                  "| Col | Header | Key | Format | Filled by |",
                  "|-----|--------|-----|--------|-----------|"]
        for col in spec.columns:
            source = "formula" if col.is_formula else "you type it"
            if col.validate:
                picked = str(col.validate.get("source", "")).lstrip("=")
                if picked and re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", picked):
                    source = f"drop down `{picked}`"
                elif not col.is_formula:
                    source = "you type it (checked)"
            if col.hidden:
                source += ", hidden"
            lines.append(f"| {spec.letter(col.key)} | {col.header} | "
                         f"`{col.key}` | {col.style} | {source} |")
        lines.append("")
    return lines


def file_table(sections: list) -> list:
    lines = ["| File | Lines | What it is |", "|------|------:|------------|"]
    for _heading, _intro, paths in sections:
        for path in paths:
            with open(os.path.join(ROOT, path), encoding="utf-8") as handle:
                count = len(handle.read().splitlines())
            note = blurb(path) or ""
            if len(note) > 110:
                note = note[:107].rsplit(" ", 1)[0] + "..."
            lines.append(f"| [`{path}`](#{anchor(path)}) | {count:,} | "
                         f"{note} |")
    return lines


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--product", choices=sorted(PRODUCTS),
                        default="pet",
                        help="which generator to export (default: pet)")
    parser.add_argument("-o", "--output", default=None)
    parser.add_argument("--plain", action="store_true",
                        help="just the code, without the architecture "
                             "chapter and the per file outlines")
    args = parser.parse_args(argv)

    product = PRODUCTS[args.product]
    sections = product["sections"]
    detailed = not args.plain

    lines = [f"# {product['title']} — source code", "",
             product["subtitle"], ""]
    lines += product["intro"]
    lines += ["", "---", "", "## Contents", ""]

    if detailed:
        lines += ["* [0. How it is put together](#0-how-it-is-put-together)",
                  "  * [The build pipeline](#the-build-pipeline)",
                  "  * [Describing a column](#describing-a-column)",
                  "  * [The rules every formula obeys]"
                  "(#the-rules-every-formula-obeys)",
                  f"  * [{product.get('engine_heading', 'The hidden `Calc` tab')}]"
                  f"(#{anchor(product.get('engine_heading', 'The hidden Calc tab'))})",
                  "  * [Every tab at a glance](#every-tab-at-a-glance)",
                  "  * [Every file at a glance](#every-file-at-a-glance)"]
    for heading, _intro, paths in sections:
        lines.append(f"* [{heading}](#{anchor(heading)})")
        for path in paths:
            lines.append(f"  * [`{path}`](#{anchor(path)})")
    if detailed:
        lines.append("* [Appendix A. Data dictionary]"
                     "(#appendix-a-data-dictionary)")
    lines += ["", "---", ""]

    if detailed:
        lines += ["## 0. How it is put together", ""]
        lines += [ARCHITECTURE.format(
            builder=product["builder"], package=product["package"],
            engine=(RANK_ENGINE if product.get("engine_heading")
                    else CALC_ENGINE),
            closing=product.get("closing", DEFAULT_CLOSING)), ""]
        tabs = tab_table(product)
        if tabs:
            lines += ["### Every tab at a glance", "",
                      f"{product['tabs']} tabs in the order they appear in "
                      f"the finished workbook. \"Rows\" is the capacity of "
                      f"a register at the default `--rows` setting.", ""]
            lines += tabs + [""]
        lines += ["### Every file at a glance", ""]
        lines += file_table(sections) + ["", "---", ""]

    total = 0
    for heading, intro, paths in sections:
        lines += [f"## {heading}", "", intro, ""]
        for path in paths:
            full = os.path.join(ROOT, path)
            with open(full, encoding="utf-8") as handle:
                code = handle.read().rstrip("\n")
            count = len(code.splitlines())
            total += count
            lines.append(f"### `{path}`")
            lines.append("")
            if detailed:
                items = outline(path)
                classes = sum(1 for kind, _n, _d in items
                              if kind == "class")
                functions = sum(1 for kind, _n, _d in items
                                if kind == "function")
                stats = [f"{count:,} lines"]
                if classes:
                    stats.append(f"{classes} class"
                                 f"{'es' if classes > 1 else ''}")
                if functions:
                    stats.append(f"{functions} function"
                                 f"{'s' if functions > 1 else ''}")
                lines += [f"*{' · '.join(stats)}*", ""]
                doc = full_docstring(path)
                if doc:
                    lines += ["> " + line if line else ">"
                              for line in doc.splitlines()]
                    lines.append("")
                named = [item for item in items if item[0] != "constant"]
                constants = [item for item in items if item[0] == "constant"]
                if named:
                    lines += ["| Defines | What it does |",
                              "|---------|--------------|"]
                    for kind, name, note in named:
                        tag = "class " if kind == "class" else ""
                        lines.append(f"| `{tag}{name}` | {note} |")
                    lines.append("")
                if constants:
                    text = ", ".join(f"`{name}` ({note})" if note
                                     else f"`{name}`"
                                     for _k, name, note in constants[:14])
                    more = (f" and {len(constants) - 14} more"
                            if len(constants) > 14 else "")
                    lines += [f"**Module constants:** {text}{more}.", ""]
            else:
                note = blurb(path)
                if note:
                    lines.append(f"{note}. *({count} lines)*")
                else:
                    lines.append(f"*({count} lines)*")
                lines.append("")
            # four backticks, so a fence inside a docstring cannot
            # close the block early
            lines += ["````python", code, "````", ""]
        lines.append("---")
        lines.append("")

    if detailed:
        dictionary = data_dictionary(product)
        if dictionary:
            lines += ["## Appendix A. Data dictionary", "",
                      "Every column of every register tab, straight from "
                      "the specs that build them: the Excel column letter, "
                      "the header a buyer sees, the key formulas use, the "
                      "number format and whether the cell is typed in, "
                      "chosen from a drop down or calculated. Pages "
                      "(dashboards, reports, printables) are not listed - "
                      "they have no fixed grid.", ""]
            lines += dictionary + ["---", ""]

    lines += [f"*{total:,} lines of Python in "
              f"{sum(len(p) for _h, _i, p in sections)} files.*", ""]

    out = args.output or product["output"]
    with open(out, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines))
    size = os.path.getsize(out)
    print(f"{out}  ({total:,} lines of source, {size / 1024:.0f} KB)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
